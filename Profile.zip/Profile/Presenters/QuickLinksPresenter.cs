﻿//-----------------------------------------------------------------------
// <copyright file="QuickLinksPresenter.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using DataAccess.Repositories;
using Newtonsoft.Json;
using Profile.Extensions;
using Profile.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using WebFormsMvp;

namespace Profile.Presenters
{
    /// <summary>
    /// Summary description of QuickLinksPresenter
    /// </summary>
    public class QuickLinksPresenter : Presenter<IView<QuickLinksModel>>
    {
        private readonly IAuthenticationRepository _authRepo;

        /// <summary>
        /// Initializes a new instance of the <see cref="QuickLinksPresenter"/> class.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="authRepo">The authentication repo.</param>
        public QuickLinksPresenter(IView<QuickLinksModel> view, IAuthenticationRepository authRepo)
            : base(view)
        {
            _authRepo = authRepo;
            View.Load += Load;
        }

        /// <summary>
        /// Loads the specified sender.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public void Load(object sender, EventArgs e)
        {
            var user = _authRepo.GetActiveUser();
            View.Model.QuickLinks = QuickLinksService.GetUserQuickLinks(user).Where(q => !q.HideDefaultLink);
        }
    }
}