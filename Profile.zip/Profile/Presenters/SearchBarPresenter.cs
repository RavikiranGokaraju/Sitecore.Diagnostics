﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.Models;
using Profile.Services;
using Profile.Extensions;
using Sitecore.ContentSearch;
using WebFormsMvp;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch;
using Taxonomy;

namespace Profile.Presenters
{
    public class SearchBarPresenter : Presenter<IView<SearchBarModel>>
    {
        private ISearchIndex index;
        /// <summary>
        /// The sitecore _context
        /// </summary>
        private ISitecoreContext _context;
        private IAuthenticationRepository _authRepo;
        private SearchService _service;

        /// <summary>
        /// Initializes a new instance of the <see cref="NewsDetailPresenter" /> class.
        /// </summary>
        /// <param name="view">The view</param>
        /// <param name="context">The context</param>
        public SearchBarPresenter(IView<SearchBarModel> view, ISitecoreContext context, IAuthenticationRepository authRepo)
            : base(view)
        {
            index = ContentSearchManager.GetIndex("users");
            
            View.Load += Load;
            _context = context;
            _authRepo = authRepo;
            _service = new SearchService(_context,_authRepo);
        }

        public void Load(object sender, EventArgs e)
        {
            BuildFacet(View.Model);
            View.Model.Labels = SearchService.GetPeopleDirectoryDisplayLabels();
        }
        private void BuildFacet(SearchBarModel model)
        {
            using (var context = index.CreateSearchContext())
            {                
                var query = context.GetQueryable<SearchProfileModel>();
                if (model.Settings.FilterFacets)
                {
                    var predicate = PredicateBuilder.True<SearchProfileModel>();
                    predicate = predicate.BuildFilter(model.Settings,model.SearchTerms);
                    query = query.Where(predicate);
                }
                query = query.FacetOnProfile(model.Settings);
                model.Facets = query.GetFacets().CleanUpFacets(model.Settings, _context);

                var skillFacetSettings = model.Settings.Facets.FirstOrDefault(f => f.FieldName.Equals("Skills", StringComparison.OrdinalIgnoreCase));

                if (skillFacetSettings != null)
                {
                    var selectedSkills = Sitecore.Context.Request.QueryString[skillFacetSettings.FieldName];
                    var skillFacetGroups = Repository.GetSkillFacetGroups();
                    model.SkillsFacetGroups = skillFacetGroups.Select(g => new SkillsFacetGroup
                    {
                        DisplayName = g.DisplayName,
                        Value = g.Value,
                        Values = g.Facets.Select(f => new FacetValueModel
                        {
                            DisplayValue = f.Display,
                            Value = f.Value,
                            Selected = selectedSkills != null && selectedSkills.Contains(f.Value)
                        })
                    });
                    model.EnableSkillsFacet = true;
                    model.SkillFacetDisplayName = skillFacetSettings.DisplayName;
                    model.SkillFacetFieldName = skillFacetSettings.FieldName;
                }
            }            
        }
    }
}