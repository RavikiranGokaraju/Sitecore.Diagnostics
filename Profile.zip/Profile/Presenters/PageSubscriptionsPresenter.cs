﻿//-----------------------------------------------------------------------
// <copyright file="PageSubscriptionsPresenter.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Business.Utils;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.App_GlobalResources;
using Profile.Models;
using Profile.Services;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq.Utilities;
using WebFormsMvp;

namespace Profile.Presenters
{
    /// <summary>
    /// Summary description of PageSubscriptionsPresenter
    /// </summary>
    public class PageSubscriptionsPresenter : Presenter<IView<Models.PageSubscriptionsModel>>
    {
        /// <summary>
        /// Holds the utils
        /// </summary>
        private SitecoreUtils sitecoreUtils = new SitecoreUtils();

        private IAuthenticationRepository _authRepo;
        private PageSubscriptionsService _service;
        private ISearchIndex index;

        public PageSubscriptionsPresenter(IView<PageSubscriptionsModel> view, IAuthenticationRepository authRepo)
            : base(view)
        {
            View.Load += this.Load;
            _authRepo = authRepo;
            _service = new PageSubscriptionsService(authRepo);
            index = ContentSearchManager.GetIndex(new SitecoreIndexableItem(Sitecore.Context.Item));
        }

        /// <summary>
        /// Loads the specified sender.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public void Load(object sender, EventArgs e)
        {
            var control = View as System.Web.UI.UserControl;
            var execute = true;
            if (control != null)
            {
                execute = !control.IsPostBack;
            }
            if (execute)
            {
                var settings = sitecoreUtils.GetDataSource<ProfileSubscriptionSettings>(this.View, ProfileResources.Default_Subscription_Settings);
                var model = new PageSubscriptionsModel {Settings = settings, Items = GetSavedforLater()};
                View.Model = model;
            }
        }

        private IEnumerable<SavedItem> GetSavedforLater()
        {
            List<SavedItem> result = null;
            var user = _authRepo.GetActiveUser();
            if (user != null)
            {
                var predicate = PredicateBuilder.True<SavedItem>();
                var items = _service.GetSaveditems();
                if (items == null || !items.Any())
                    return null;
                foreach (var item in _service.GetSaveditems())
                {
                    predicate = predicate.Or(x => x.Id == item.Guid);
                }
                using (var context = index.CreateSearchContext())
                {
                    var query = context.GetQueryable<SavedItem>();
                    query = query.Where(predicate);
                    query = query.OrderBy(x => x.Modified);
                    result = query.ToList();
                }
            }
            return result;
        }
    }
}