﻿//-----------------------------------------------------------------------
// <copyright file="ItemEventHandler.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Linq;
using System.Net;
using System.Collections.Generic;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
//using Search.App_Resources.Components.Search_Components;
//using Search.Extensions;
//using Search.Models;
//using Search.Services;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.Globalization;
using WebFormsMvp;
using Sitecore.Data;
using Profile.Services;
using Profile.Models;
using Sitecore.ContentSearch.Linq.Utilities;
using Profile.Extensions;
using Sitecore.Diagnostics;
using System.Text.RegularExpressions;

namespace Profile.Presenters
{
    public class SearchResultsPresenter : Presenter<IView<SearchResultsModel>>
    {
        private static Regex PayIdRegex = new Regex(Sitecore.Configuration.Settings.GetAppSetting("Profile.PayId.Regex", "^[0-9]{7}$"), RegexOptions.Compiled);
        private ISearchIndex index;
        /// <summary>
        /// The sitecore _context
        /// </summary>
        private ISitecoreContext _context;
        private IAuthenticationRepository _authRepo;

        /// <summary>
        /// Initializes a new instance of the <see cref="NewsDetailPresenter" /> class.
        /// </summary>
        /// <param name="view">The view</param>
        /// <param name="context">The context</param>
        public SearchResultsPresenter(IView<Models.SearchResultsModel> view, ISitecoreContext context, IAuthenticationRepository authRepo)
            : base(view)
        {
            index = ContentSearchManager.GetIndex("users");
            
            View.Load += Load;
            _context = context;
            _authRepo = authRepo;

        }

        /// <summary>
        /// The page load event
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event args</param>
        //public void Load(object sender, EventArgs e)
        //{
        //    //SetLabels();
        //    //if (!string.IsNullOrWhiteSpace(View.Model.Term) ||
        //    //    (View.Model.SearchSettings.PageType == null ||
        //    //     View.Model.SearchSettings.PageType.Name.Equals("news", StringComparison.InvariantCultureIgnoreCase)))
        //    //    Search();
        //    //else
        //    //    View.Model.ShowEmptySearchTermMessage = true;
        //}
        public void Load(object sender, EventArgs e)
        {
            Search(View.Model);
            View.Model.Labels = SearchService.GetPeopleDirectoryDisplayLabels();
        }
        private void Search(SearchResultsModel model)
        {
            using (var context = index.CreateSearchContext())
            {
                
                var query = context.GetQueryable<SearchProfileModel>();
                
                    var predicate = PredicateBuilder.True<SearchProfileModel>();
                    predicate = predicate.BuildFilter(model.Settings, model.SearchTerms);
                    query = query.Where(predicate);
                    query = query.ApplyOrder(model.Settings, _context);
                    if (model.Settings.MaxResults > 0)
                        query = query.Take(model.Settings.MaxResults);
                
                //query = query.FacetOnProfile(model.Settings);
                model.People = query.GetResults().Hits.Select(d=>d.Document).Where(d => IsValidPayId(d.PayRolId)).ToList();
            }
            
        }

        private static bool IsValidPayId(string payId)
        {
            return !string.IsNullOrWhiteSpace(payId) && PayIdRegex.IsMatch(payId);
        }

        //    private void SetLabels()
        //    {
        //        View.Model.Lables = new SearchDisplayLabels
        //            {
        //                ApplyButtonText = Translate.Text(DictionaryLabels.ApplyButtonText),
        //                BusinessAreaFilterName = Translate.Text(DictionaryLabels.BusinessAreaFilterName),
        //                ClearButtonText = Translate.Text(DictionaryLabels.ClearButtonText),
        //                ContentTagFilterName = Translate.Text(DictionaryLabels.ContentTagFilterName),
        //                ContentTagFilterPlaceholder = Translate.Text(DictionaryLabels.ContentTagFilterPlaceholder),
        //                DateFilterName = Translate.Text(DictionaryLabels.DateFilterName),
        //                DocumentTypeFilterName = Translate.Text(DictionaryLabels.DocumentTypeFilterName),
        //                DocumentsFilterName = Translate.Text(DictionaryLabels.DocumentsFilterName),
        //                DocumentsFilterText = Translate.Text(DictionaryLabels.DocumentsFilterText),
        //                NewsSearchPlaceholder = Translate.Text(DictionaryLabels.NewsSearchPlaceholder),
        //                SearchPlaceholder = Translate.Text(DictionaryLabels.SearchPlaceholder),
        //                NoResultsText = Translate.Text(DictionaryLabels.NoResultsText),
        //                NewsHeader = Translate.Text(DictionaryLabels.NewsHeader),
        //                SearchHeader = Translate.Text(DictionaryLabels.SearchHeader),
        //                EmptySearchtermText = Translate.Text(DictionaryLabels.EmptySearchtermText)
        //            };
        //    }

        //    public void Search()
        //    {
        //        using (var context = index.CreateSearchContext())
        //        {
        //            SearchService.LogSearch(View.Model.Term);
        //            var terms = SearchExtensions.GetPreferredTerms(View.Model.Term).ToList();
        //            var predicate = View.Model.DocumentsOnly.IsSelected
        //                                ? SearchExtensions
        //                                      .GetPredicate()
        //                                      .AddSearchTerm(terms.ToList(), View.Model.DocumentsOnly.IsSelected)
        //                                      //.WithFromDate(View.Model.FromDate)
        //                                      //.WithToDate(View.Model.ToDate)
        //                                      .WithContentTag(View.Model.SelectedContentTag)
        //                                : SearchExtensions
        //                                      .GetPredicate()
        //                                      .AddSearchTerm(terms.ToList())
        //                                      .WithPageTypes(View.Model.PageTypes.Where(p => p.IsSelected).ToList())
        //                                      .WithBusinessStream(View.Model.BusinessStreams.Where(b => b.IsSelected).ToList())
        //                                      .WithFromDate(View.Model.FromDate)
        //                                      .WithToDate(View.Model.ToDate)
        //                                      .WithContentTag(View.Model.SelectedContentTag);

        //            var query = View.Model.DocumentsOnly.IsSelected
        //                            ? context
        //                                  .GetQueryable<SearchResult>()
        //                                  .SetDocumentFilter()
        //                                  .Where(predicate)
        //                            : context
        //                                  .GetQueryable<SearchResult>()
        //                                  .SetDefaultFilter()
        //                                  .Where(predicate);

        //            if (View.Model.SearchSettings.PageType != null && View.Model.SearchSettings.PageType.Name.Equals("news", StringComparison.InvariantCultureIgnoreCase))
        //                query = query.OrderByDescending(x => x.IssuedDate);

        //            var results = query.GetResults();
        //            View.Model.ResultCount = Math.Min(results.TotalSearchResults, View.Model.MaxCount);
        //            View.Model.HighlightTerms = WebUtility.HtmlEncode(JsonConvert.SerializeObject(terms));
        //            View.Model.PrefferedTerms = terms;

        //            View.Model.ResultList = results
        //                    .Hits.Take(View.Model.MaxCount).Select(x => x.Document)
        //                    .Skip((View.Model.PageNumber - 1) * View.Model.PageSize)
        //                    .Take(View.Model.PageSize).ToList();
        //            SavedForLaterService service = new SavedForLaterService(_context, _authRepo);
        //            View.Model.ResultList.ForEach(x => x.IsSaved = service.IsSavedItem(x.SitecoreId));
        //        }
        //    }
    }
}