﻿//-----------------------------------------------------------------------
// <copyright file="AlertListingPresenter.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Base.Models;
using Business.Utils;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.App_GlobalResources;
using Profile.Models;
using Profile.Extensions;
using WebFormsMvp;
using Profile.Services;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.ContentSearch;

namespace Profile.Presenters
{
    /// <summary>
    /// Summary description of AlertListingPresenter
    /// </summary>
    public class SavedForLaterPresenter : Presenter<IView<Models.SavedForLaterModel>>
    {
        /// <summary>
        /// Holds the utils
        /// </summary>
        private SitecoreUtils sitecoreUtils = new SitecoreUtils();

        /// <summary>
        /// The sitecore _context
        /// </summary>
        private ISitecoreContext _context;
        private IAuthenticationRepository _authRepo;
        private SavedForLaterService _safefor;
        private ISearchIndex index;

        /// <summary>
        /// Initializes a new instance of the <see cref="GlobalAlertsPresenter"/> class.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="context">The context.</param>
        public SavedForLaterPresenter(IView<SavedForLaterModel> view, ISitecoreContext context, IAuthenticationRepository authRepo)
            : base(view)
        {
            this.View.Load += this.Load;
            _context = context;
            _authRepo = authRepo;
            _safefor = new SavedForLaterService(context, authRepo);
            index = ContentSearchManager.GetIndex(new SitecoreIndexableItem(Sitecore.Context.Item));
        }

        /// <summary>
        /// Loads the specified sender.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public void Load(object sender, EventArgs e)
        {
            System.Web.UI.UserControl control = this.View as System.Web.UI.UserControl;
            bool execute = true;
            if (control != null)
            {
                execute = !control.IsPostBack;
            }
            if (execute)
            {
                var settings = sitecoreUtils.GetDataSource<SavedForLaterSettings>(this.View, ProfileResources.Default_Daved_For_Later_settings);
                var model = new SavedForLaterModel();
                model.Settings = settings;
                model.Items = GetSavedforLater();
                View.Model = model;

            }            
        }

        private IEnumerable<SavedItem> GetSavedforLater()
        {
            List<SavedItem> result = null;
            var user = _authRepo.GetActiveUser();
            if (user != null)
            {
                var predicate = PredicateBuilder.True<SavedItem>();

                foreach (var item in _safefor.GetSaveditems())
                {
                    predicate = predicate.Or(x => x.Id == item.Guid);                                  
                }
                using (var context = index.CreateSearchContext())
                {
                    var query = context.GetQueryable<SavedItem>();
                    query = query.Where(predicate);
                    query = query.OrderBy(x => x.Modified);
                    result = query.ToList();
                }

            }
            return result;
        }
    }
}