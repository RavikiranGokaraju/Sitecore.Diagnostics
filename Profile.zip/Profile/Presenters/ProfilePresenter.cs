﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.Models;
using WebFormsMvp;
using Sitecore.ContentSearch;
using Profile.Services;
using Profile.Extensions;
using Taxonomy;
using Base.Models;
using Sitecore.Data;
using Option = Base.Models.Option;
using Profile.Cache;
using Sitecore.Security;
using Sitecore.Diagnostics;

namespace Profile.Presenters
{
    public class ProfilePresenter : Presenter<IView<ProfileModel>>
    {
        /// <summary>
        /// The sitecore _context
        /// </summary>
        private ISitecoreContext _context;
        private IAuthenticationRepository _authRepo;
        private ISearchIndex index;
        private SearchService _service;

        /// <summary>
        /// Initializes a new instance of the <see cref="NewsDetailPresenter" /> class.
        /// </summary>
        /// <param name="view">The view</param>
        /// <param name="context">The context</param>
        public ProfilePresenter(IView<Models.ProfileModel> view, ISitecoreContext context, IAuthenticationRepository authRepo)
            : base(view)
        {
            View.Load += Load;
            index = ContentSearchManager.GetIndex("users");
            _context = context;
            _authRepo = authRepo;
            _service = new SearchService(context, authRepo, index);
        }

        public void Load(object sender, EventArgs e)
        {
            View.Model.Labels = SearchService.GetPeopleDirectoryDisplayLabels();
            if (!string.IsNullOrWhiteSpace(View.Model.RequestedSitecoreid))
            {
                Search(View.Model);
                SetEditMode();
                if (View.Model.Profile != null)
                    View.Model.TeamStructure = View.Model.Profile.GetTeamStructure();
            }
        }
        private void SetEditMode()
        {
            View.Model.EditMode = false;
            
            if (View.Model.Profile != null)
            {
                var activeuser = _authRepo.GetActiveUser();
                
                if (activeuser != null)
                {
                    //SetEditFields(View.Model.Profile, activeuser.Profile);
                    View.Model.EditMode = activeuser.Profile.GetPayId() == View.Model.Profile.PayRolId;
                    if (View.Model.EditMode)
                    {                        
                        SetFullListOfSubscriptions(View.Model.Profile, activeuser.Profile);
                        SetSkillsFullList(View.Model.Profile, activeuser.Profile);
                        SetExpertiseFullList(View.Model.Profile, activeuser.Profile);
                        SetSpecialRoleFullList(View.Model.Profile, activeuser.Profile);
                    }
                }
            }
        }

        private void SetSpecialRoleFullList(SearchProfileModel p, UserProfile profile)
        {
            var currentList = profile[User.SPECIALROLE];
            var fullList = Repository.GetSpecialRoles().ToList();
            var temp = new List<Option>(fullList.Count());
            foreach (var item in fullList)
            {
                Log.Info("Match Item:" + item.Value, new object());
                var o = new Option
                {
                    Display = item.Display,
                    Value = item.Value,
                    Selected =
                        !string.IsNullOrEmpty(currentList) &&
                        currentList.Split('|').Where(x => x != null).Where(x => ID.IsID(x)).Any(y => new ID(y).ToShortID().ToString() == item.Value)
                };
                temp.Add(o);
            }
            p.SpecialRoleFullList = temp;
        }

        private void SetEditFields(SearchProfileModel p, UserProfile profile)
        {
            p.Status = profile[User.STATUS];
            p.LicensePlate = profile[User.LICENSEPLATE];
            p.Telephone = profile[User.TELEPHONENUMBER];
            p.MobileNumber = profile[User.MOBILENUMBER];
        }

        private static void SetExpertiseFullList(SearchProfileModel p, UserProfile profile)
        {
            var currentList = profile[Profile.Extensions.User.INTERESTS];
            var fullList = Repository.GetExpertise().ToList();
            var temp = new List<Option>(fullList.Count());
            foreach (var item in fullList)
            {
                var o = new Option
                {
                    Display = item.Display,
                    Value = item.Value,
                    Selected =
                        !string.IsNullOrEmpty(currentList) &&
                        currentList.Split('|').Where(x => x != null).Where(x => ID.IsID(x)).Any(y => new ID(y).ToShortID().ToString() == item.Value)
                };
                temp.Add(o);
            }
            p.ExpertiseFullList = temp;
        }

        private static void SetSkillsFullList(SearchProfileModel p, UserProfile profile)
        {
            var currentList = profile[Profile.Extensions.User.SKILLS];
            
            var fullList = Repository.GetSkills().ToList();
            var temp = new List<Option>(fullList.Count());
            foreach (var item in fullList)
            {
                Log.Info("Match Item:" + item.Value, new object());
                var o = new Option
                {
                    Display = item.Display,
                    Value = item.Value,
                    Selected =
                        !string.IsNullOrEmpty(currentList) &&
                        currentList.Split('|').Where(x => x != null).Where(x => ID.IsID(x)).Any(y => new ID(y).ToShortID().ToString() == item.Value)
                };
                temp.Add(o);
            }
            p.SkillsFullList = temp;

            var skillsFacetGroups = Repository.GetSkillFacetGroups();
            var currentValues = currentList.Replace("{", "").Replace("}", "").Replace("-", "");
            p.SkillsFacetGroups = skillsFacetGroups.Select(g => new SkillsFacetGroup
            {
                DisplayName = g.DisplayName,
                Value = g.Value,
                Values = g.Facets.Select(f => new FacetValueModel
                {
                    DisplayValue = f.Display,
                    Value = f.Value,
                    Selected = currentValues.Contains(f.Value)
                })
            });
        }

        private static void SetFullListOfSubscriptions(SearchProfileModel p, UserProfile profile)
        {
            var currentList = profile[Profile.Extensions.User.SUBSCRIPTIONS];
            var fullList = Repository.GetBusinessStreams().ToList();
            var temp = new List<Option>(fullList.Count());
            foreach (var item in fullList)
            {
                var o = new Option
                    {
                        Display = item.DisplayName,
                        Value = item.Id,
                        Selected =
                            !string.IsNullOrEmpty(currentList) &&
                            currentList.Split('|').Where(x => x != null).Where(x => ID.IsID(x)).Any(y => new ID(y).ToShortID().ToString() == item.Id)
                    };
                temp.Add(o);
            }
            p.SubscriptionsFullList = temp;
        }
        private static void Search(ProfileModel model)
        {
            if (!string.IsNullOrWhiteSpace(model.RequestedSitecoreid))
                model.Profile = SearchService.GetProfile(model.RequestedSitecoreid);
        }
    }
}