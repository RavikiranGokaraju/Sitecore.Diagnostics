﻿//-----------------------------------------------------------------------
// <copyright file="PageSubscriptions.ascx.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business.Global;
using Profile.Models;

namespace Profile.Components.Profile_Components
{
    /// <summary>
    /// Summary description for PageSubscriptions
    /// </summary>
    public partial class PageSubscriptions : CpMvpUserControl<PageSubscriptionsModel>
    {
        /// <summary>
        /// The page load event
        /// </summary>
        /// <param name="sender">The object sender</param>
        /// <param name="e">The event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}