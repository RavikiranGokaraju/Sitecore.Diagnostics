﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business.Global;
using Business.Utils;
using Profile.Cache;
using Profile.Models;

namespace Profile.Components.Profile_Components
{
    public partial class Profile : CpMvpUserControl<ProfileModel >
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SetModel();            
        }
        protected void SetModel()
        {            
            if (!string.IsNullOrWhiteSpace(Request.QueryString["profile"]))
            {
                Model.RequestedSitecoreid = Request.QueryString["profile"];
            }
            if (ProfileCacheManager.ProfileCache.PeopleDirectorySettings == null)
            {
                var sitecoreUtils = new SitecoreUtils();
                var settings = sitecoreUtils.GetDataSource<SearchSettings>(this, "");
                Model.Settings = (ProfileDetailsSettings)settings;
                ProfileCacheManager.ProfileCache.PeopleDirectorySettings = Model.Settings;
            }
            else
                Model.Settings = ProfileCacheManager.ProfileCache.PeopleDirectorySettings;
        }
    }
}