﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using Business.Global;
using Business.Utils;
using Profile.Cache;
using Profile.Models;

namespace Profile.Components.Profile_Components
{
    public abstract class SearchView<T> : CpMvpUserControl<T> where T : SearchModel, new()
    {        
        protected void Page_Load(object sender, EventArgs e)
        {
            SetModel(); 
            //RegisterClientSideScripts();
        }
        protected void SetModel()
        {
            var sitecoreUtils = new SitecoreUtils();
            Model.Settings = sitecoreUtils.GetDataSource<SearchSettings>(this, "");
            if (ProfileCacheManager.ProfileCache.PeopleDirectorySettings == null)
            {
                
                ProfileCacheManager.ProfileCache.PeopleDirectorySettings = (ProfileDetailsSettings)Model.Settings;
            }
            
            //Model.PageSize = Model.SearchSettings.ResultsPerPage;
            //Model.MaxCount = Model.SearchSettings.MaxResults;
            Model.Settings.PageNumber = !string.IsNullOrWhiteSpace(Request.QueryString["pageNumber"]) ? Convert.ToInt32(Request.QueryString["pageNumber"]) : 1;
            if (Model.Settings != null && Model.Settings.Facets != null && Model.Settings.Facets.Any())
            {
                foreach (var item in Model.Settings.Facets)
                {
                    if (!string.IsNullOrWhiteSpace(Request.QueryString[item.FieldName]))
                    {
                        item.Searchvalue = WebUtility.HtmlDecode(Request.QueryString[item.FieldName]);
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(Request.QueryString[SearchModel.SearchTermName]))
            {
                Model.SearchTerms = WebUtility.HtmlDecode(Request.QueryString[SearchModel.SearchTermName]);
            }
            
        }

        //private void RegisterClientSideScripts()
        //{
        //    if (!Page.ClientScript.IsStartupScriptRegistered(typeof(SearchView<>), "ProfileSearchScripts"))
        //    {
        //        var script = @"<script type=""text/javascript"" src=""/assets/scripts/custom/ProfileSearch.js""></script>";
        //        Page.ClientScript.RegisterStartupScript(typeof(SearchView<>), "ProfileSearchScripts", script, false);
        //    }
        //}
    }
}