﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Base.Models;
using Business.Global;
using Sitecore.ContentSearch;
//using Sitecore.ContentSearch.Linq.Utilities;
//using Sitecore.ContentSearch.Linq;
using Business.Utils;
using Sitecore.Data;
//using Search.Extensions;
using Sitecore.Data.Managers;
using Profile.Models;

namespace Profile.Components.Profile_Components
{
    public partial class SearchResults : SearchView<SearchResultsModel>
    {
        //protected void Page_Load(object sender, EventArgs e)
        //{
            //SetModel();

            //if (!string.IsNullOrWhiteSpace(Request.QueryString["query"]))
            //{
            //    var term = Request.QueryString["query"];
            //    var disableSpellCheck = false;
            //    if (!string.IsNullOrWhiteSpace(Request.QueryString["disableSpellCheck"]))
            //        bool.TryParse(Request.QueryString["disableSpellCheck"], out disableSpellCheck);
            //    if (!disableSpellCheck)
            //    {
            //        var isSpellingCorrect = HunspellSpellCheck.SpellCheck(term);
            //        if (!isSpellingCorrect)
            //        {
            //            var suggestions = HunspellSpellCheck.GetSuggestions(term).ToList();
            //            if (suggestions.Any())
            //            {
            //                Model.ShowSuggestion = true;
            //                var firstSuggestion = suggestions.First();
            //                suggestions = suggestions.Skip(1).ToList();
            //                suggestions.Insert(0, term);
            //                Model.Suggestions = suggestions;
            //                Model.Term = firstSuggestion;
            //            }
            //            else
            //            {
            //                Model.Term = term;
            //            }
            //        }
            //        else
            //        {
            //            Model.Term = term;
            //        }
            //    }
            //    else
            //    {
            //        Model.Term = term;
            //    }
            //}
        //}

        //private void SetModel()
        //{
            //Model.SearchSettings = GlassHtml.GetRenderingParameters<Models.SearchSettings>(Attributes["sc_parameters"]);
            //Model.PageSize = Model.SearchSettings.ResultsPerPage;
            //Model.MaxCount = Model.SearchSettings.MaxResults;
            //Model.PageNumber = !string.IsNullOrWhiteSpace(Request.QueryString["pageNumber"]) ? Convert.ToInt32(Request.QueryString["pageNumber"]) : 1;
            //Model.DocumentsOnly = new FilterItem
            //    {
            //        DisplayName = "Documents Only",
            //        UniqueId = "true"
            //    };
            //if (!string.IsNullOrWhiteSpace(Request.QueryString["docOnly"]))
            //{
            //    Model.DocumentsOnly.IsSelected = Request.QueryString["docOnly"] == "true";
            //}
            //Model.PageTypes = FilterItem.GetFilterItems(Taxonomy.Repository.GetPageTypes(), Request.QueryString["pagetypes"]);
            //Model.BusinessStreams = FilterItem.GetFilterItems(Taxonomy.Repository.GetBusinessStreams(), Request.QueryString["streams"]);

            //if (!string.IsNullOrWhiteSpace(Request.QueryString["fromdate"]))
            //{
            //    Model.FromDate = DateTime.ParseExact(Request.QueryString["fromdate"], "dd/MM/yy", System.Globalization.CultureInfo.InvariantCulture);
            //}

            //if (!string.IsNullOrWhiteSpace(Request.QueryString["todate"]))
            //{
            //    Model.ToDate = DateTime.ParseExact(Request.QueryString["todate"], "dd/MM/yy", System.Globalization.CultureInfo.InvariantCulture);
            //}

            //if (!string.IsNullOrWhiteSpace(Request.QueryString["contenttag"]))
            //{
            //    Model.SelectedContentTag = Request.QueryString["contenttag"];
            //}
        //}
    }
}