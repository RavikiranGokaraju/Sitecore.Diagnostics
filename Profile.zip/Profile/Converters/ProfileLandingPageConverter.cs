﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Web;
using Base.Models;
using Glass.Mapper.Sc;
using Glass.Mapper.Sc.Configuration;
using Sitecore.Data;
using Profile.Models;

namespace Profile.Converters
{
	public class ProfileLandingPageConverter : TypeConverter
	{
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			var scContext = new SitecoreContext();
			var config = Glass.Mapper.Context.Default.GetTypeConfiguration<SitecoreTypeConfiguration>(sourceType, true);
			if (config != null && (sourceType == typeof(ProfileLandingPage) || sourceType == typeof(IEnumerable<ProfileLandingPage>)))
			{
				return true;
			}
			else
				return base.CanConvertFrom(context, sourceType);
		}

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			if (destinationType == typeof(string))
				return true;
			else
				return base.CanConvertTo(context, destinationType);
		}

		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			object result = null;
			if (value is string)
			{
				result = Createinstance((string)value);
			}
			else if (value is Array)
			{
				Array vararray = (Array)value;
				foreach (string id in vararray)
				{
					result = Createinstance(id);
					if (result != null)
						break;
				}
			}
			return result;
		}

		private object Createinstance(string id)
		{
			var scContext = new SitecoreContext();
			object result = null;
			Guid x = Guid.Empty;
			if (Guid.TryParse(id, out x))
			{
				var item = scContext.Database.GetItem(x.ToString());
				if (item != null)
					result = scContext.CreateType(typeof(ProfileLandingPage), item, true, false, new Dictionary<string, object>());
			}
			return result;

		}

		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			var config = Glass.Mapper.Context.Default.GetTypeConfiguration<SitecoreTypeConfiguration>(value.GetType(), true);
			ID id = config.GetId(value);
			return id.ToShortID().ToString().ToLowerInvariant();
		}
	}
}