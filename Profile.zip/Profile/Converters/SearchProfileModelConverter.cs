﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Web;
using Profile.Models;
using Profile.Services;

namespace Profile.Converters
{
    public class SearchProfileModelConverter : TypeConverter
    {

        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(SearchProfileModel) || sourceType == typeof(IEnumerable<SearchProfileModel>) || sourceType == typeof(string))
            {
                return true;
            }
            else
                return base.CanConvertFrom(context, sourceType);
        }

        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(string))
                return true;
            else
                return base.CanConvertTo(context, destinationType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            object result = null;
            if (value is string)
            {
                result = Createinstance((string)value);
            }
            else if (value is Array)
            {
                Array vararray = (Array)value;
                foreach (string id in vararray)
                {
                    result = Createinstance(id);
                    if (result != null)
                        break;
                }
            }
            return result;
        }

        private object Createinstance(string id)
        {
            object result = null;

            result = SearchService.GetProfile(id);
            return result;

        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            SearchProfileModel prof = value as SearchProfileModel;
            if (prof != null)
                return prof.PayRolId;
            else
                return string.Empty;
        }
    }
}