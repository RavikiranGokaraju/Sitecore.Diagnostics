﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Sitecore.Data;
using Sitecore.Globalization;
using Sitecore.Security;
using Profile.Extensions;
using Profile.Models;

namespace Profile.Services
{
    public class SavedForLaterService
    {
        /// <summary>
        /// Holds the context
        /// </summary>
        private readonly ISitecoreContext sitecoreContext;
        private readonly IAuthenticationRepository _authRepo;
        private readonly ISitecoreContext _sitecore;
        private readonly UserProfile _prof;

        public SavedForLaterService(ISitecoreContext context = null, IAuthenticationRepository authRepo = null, ISitecoreContext sitecore = null)
        {
            sitecoreContext = context ?? new SitecoreContext();
            _authRepo = authRepo ?? new AuthenticationRepository();
            _sitecore = sitecore ?? new SitecoreContext();
            var usr = _authRepo.GetActiveUser();
            if (usr != null)
                _prof = usr.Profile;
        }

        public UserQuickActionResult SaveItem(string id)
        {
            var popupHeader = Translate.Text("Saved_Item_Popup_Header");
            if (_prof != null)
            {
                var settings =
                    _sitecore.GetItem<SavedForLaterSettings>(
                        App_GlobalResources.ProfileResources.Default_Daved_For_Later_settings);
                if (settings != null)
                {


                    if (ID.IsID(id))
                    {
                        var result = _prof.AddOrRemoveSavedItems(ID.Parse(id), settings);
                        switch (result.ResultStatus)
                        {
                            case UserQuickActionResultEnum.ItemAdded:
                                _prof.Save();
                                result.PopupHeader = popupHeader;
                                result.PopupText = Translate.Text("Saved_Item_Add_Text");
                                break;
                            case UserQuickActionResultEnum.ItemRemoved:
                                result.PopupHeader = popupHeader;
                                result.PopupText = Translate.Text("Saved_Item_Remove_Text");
                                _prof.Save();
                                break;
                            case UserQuickActionResultEnum.MaxLimitReached:
                                result.PopupHeader = popupHeader;
                                result.PopupText = string.Format(settings.LimitExceededError,
                                                                 settings.MaxSavedItems.ToString());
                                break;
                            case UserQuickActionResultEnum.Error:
                                result.PopupHeader = popupHeader;
                                result.PopupText = "Unalble to perform action. Please contact administrator";
                                break;
                        }
                        return result;
                    }
                    return new UserQuickActionResult
                        {
                            ResultStatus = UserQuickActionResultEnum.Error,
                            PopupHeader = popupHeader,
                            PopupText = "The ID is not a valid ID"
                        };
                }
                return new UserQuickActionResult
                    {
                        ResultStatus = UserQuickActionResultEnum.Error,
                        PopupHeader = popupHeader,
                        PopupText =
                            "Unable to find the saved settings item: {847BD63E-21DC-41ED-BAD5-5BA8059A7EAA}"
                    };
            }
            return new UserQuickActionResult
                {
                    ResultStatus = UserQuickActionResultEnum.Error,
                    PopupHeader = popupHeader,
                    PopupText = "Unable to get the current profile"
                };
        }

        public IList<ID> GetSaveditems()
        {
            return _prof.GetSavedItems() ?? new List<ID>();
        }

        public bool IsSavedItem(ID id)
        {
            bool result = false;
            if (_prof != null)
            {
                var list = _prof.GetSavedItems();
                if (list != null)
                    result = list.Contains(id);
            }
            return result;
        }

        public bool IsSavedItem(string id)
        {
            bool result = false;
            if (_prof != null)
            {
                var list = _prof.GetSavedItems();
                if (list != null)
                    result = list.Contains(ID.Parse(id));
            }
            return result;
        }
    }
}