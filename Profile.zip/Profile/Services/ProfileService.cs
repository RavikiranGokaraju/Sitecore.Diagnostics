﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.Extensions;
using Profile.Models;
using Sitecore.Data;
using Sitecore.Diagnostics;
using Utils.Email;
using System.Drawing.Imaging;

namespace Profile.Services
{
    public class ProfileService
    {
         /// <summary>
        /// Holds the context
        /// </summary>
        private readonly ISitecoreContext sitecoreContext;
        private readonly IAuthenticationRepository _authRepo;

        public ProfileService(ISitecoreContext context = null, IAuthenticationRepository authRepo = null)
        {
            sitecoreContext = context ?? new SitecoreContext();
            _authRepo = authRepo ?? new AuthenticationRepository();                 
        }

        public bool SetStatus(string status)
        {
            var profile = _authRepo.GetActiveUser();
            if (profile != null)
            {
                profile.Profile.SetStatus(status);
                profile.Profile.Save();
                return true;
            }
            return false;
        }

        public bool SaveProfile(SearchProfileModel p)
        {
            var profile = _authRepo.GetActiveUser();
            if (profile != null)
            {
                profile.Profile.SetStatus(p.Status);
                if (p.SpecialRoleFullList != null && p.SpecialRoleFullList.Any(x => x != null && x.Selected))
                    profile.Profile.SetSpecialRole(string.Join("|", p.SpecialRoleFullList.Where(x => x != null && x.Selected).Select(x => ShortID.DecodeID(x.Value).ToString()).ToArray()));
                else
                    profile.Profile.SetSpecialRole(string.Empty);
                //profile.Profile.SetLicensePlate(p.LicensePlate);
                profile.Profile.SetShowImage(p.ShowImage);
                profile.Profile.SetContactNumbers(p.Telephone, p.MobileNumber);
                if (p.SubscriptionsFullList != null && p.SubscriptionsFullList.Any(x => x != null && x.Selected))
                    profile.Profile.SetSubscriptions(string.Join("|", p.SubscriptionsFullList.Where(x => x != null && x.Selected).Select(x => ShortID.DecodeID(x.Value).ToString()).ToArray()));
                else
                    profile.Profile.SetSubscriptions(string.Empty);
                if (p.SkillsFullList != null && p.SkillsFullList.Any(x => x != null && x.Selected))
                    profile.Profile.SetSkills(string.Join("|", p.SkillsFullList.Where(x => x != null && x.Selected).Select(x => ShortID.DecodeID(x.Value).ToString()).ToArray()));
                else
                    profile.Profile.SetSkills(string.Empty);
                if (p.ExpertiseFullList != null && p.ExpertiseFullList.Any(x => x != null && x.Selected))
                    profile.Profile.SetExpertise(string.Join("|", p.ExpertiseFullList.Where(x => x != null && x.Selected).Select(x => ShortID.DecodeID(x.Value).ToString()).ToArray()));
                else
                    profile.Profile.SetExpertise(string.Empty);
                profile.Profile.Save();                
                return true;
            }
            return false;

        }
        public bool SaveNewImage(HttpPostedFile image)
        {
            Assert.ArgumentNotNull(image,"Uploaded image");
            try
            {
                var profile = _authRepo.GetActiveUser();
                if (profile != null)
                {
                    SearchSettings settings = sitecoreContext.GetItem<SearchSettings>(App_GlobalResources.ProfileResources.Default_PeopleDirectory_Settings);
                    if (settings != null)
                    {
                        if (!string.IsNullOrWhiteSpace(settings.ExternalDirectoryPath))
                        {
                            if (Directory.Exists(settings.ExternalDirectoryPath))
                            {
                                string imagepath = settings.ExternalDirectoryPath + profile.Profile.GetPayId() + "_" + Path.GetRandomFileName() + "" + Path.GetExtension(image.FileName);
                                var temppath = settings.ExternalDirectoryPath + "Original_" + profile.Profile.GetPayId() + "_" + Path.GetRandomFileName() + "" + Path.GetExtension(image.FileName);
                                image.SaveAs(temppath);
                                var resizedPhoto = ImageExtensions.ResizeImagePropotionately(temppath, settings.MaxWidth, settings.MaxHeight);
                                resizedPhoto.Save(imagepath, ImageFormat.Jpeg);
                                SendSavedImageNotification(imagepath);
                            }
                            Log.Warn("The location for saving the new profile images does not exist", this);
                        }
                        Log.Warn("The location for saving the new profile images is empty", this);
                    }
                    Log.Warn("The settings for saving the new profile images are empty", this);
                }
                Log.Warn("Unable to get the current user for saving the new profile", this);
            }
            catch (Exception ex)
            {
                Log.Error("Error saving the profile image uploaded by the user. " + ex.Message, this);
                return false;
            }
                
            return true;

        }
        private void SendSavedImageNotification(string newimage)
        {
            var profile = _authRepo.GetActiveUser();
            if (profile != null)
            {
                SearchSettings settings = sitecoreContext.GetItem<SearchSettings>(App_GlobalResources.ProfileResources.Default_PeopleDirectory_Settings);
                NewProfileImageNotification notification = new NewProfileImageNotification();
                notification.NewImage = newimage;
                notification.PayId = profile.Profile.GetPayId();
                var emailwrapper = new BulkEmail<NewProfileImageNotification>();
                emailwrapper.EmailName = "new profile image";
                emailwrapper.FromAdress = settings.EmailFromAdress;
                emailwrapper.FromName = settings.EmailFromName;
                emailwrapper.IsHtml = settings.IsHtml;
                emailwrapper.Subject = settings.EmailSubject;
                emailwrapper.SmtpHost = settings.SmtpSettings.SmtpHost;
                emailwrapper.SmtpPassword = settings.SmtpSettings.SmtpPassword;
                emailwrapper.SmtpUserName = settings.SmtpSettings.SmtpUserName;
                emailwrapper.Template = settings.EmailTemplate;

                var email = new SingleEmail<NewProfileImageNotification>(emailwrapper);
                email.ToAdress = settings.SendNotificationTo;
                email.items.Add(notification);
                emailwrapper.Emails.Add(email);
                EmailManager.SendEmail<NewProfileImageNotification>(emailwrapper);
            }

        }


    }
}