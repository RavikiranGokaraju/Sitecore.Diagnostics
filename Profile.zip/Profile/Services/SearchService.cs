﻿using System.Collections.Generic;
using System.Linq;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.App_GlobalResources;
using Profile.Models;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.Globalization;
using Profile.Extensions;
using Sitecore.ContentSearch.Linq.Utilities;
using Profile.Cache;
using Sitecore.Data;

namespace Profile.Services
{
    public class SearchService
    {
        /// <summary>
        /// Holds the context
        /// </summary>
        //private readonly ISitecoreContext sitecoreContext;
        //private readonly IAuthenticationRepository _authRepo;
        private static readonly ISearchIndex _index = ContentSearchManager.GetIndex("users");

        public SearchService(ISitecoreContext context = null, IAuthenticationRepository authRepo = null, ISearchIndex index = null)
        {
            //sitecoreContext = context ?? new SitecoreContext();
            //_authRepo = authRepo ?? new AuthenticationRepository();              
        }

        public static PeopleDirectoryDisplayLabels GetPeopleDirectoryDisplayLabels()
        {
            var labels = new PeopleDirectoryDisplayLabels();
            labels.ApplyButtonText = Translate.Text(ProfileResources .ApplyButtonText);
            labels.ClearButtonText = Translate.Text(ProfileResources.ClearText);
            labels.EmailText = Translate.Text(ProfileResources.EmailText);
            labels.EmptySearchtermText = string.Empty;
            labels.HeaderText = Translate.Text(ProfileResources.HeaderText);
            labels.MobileText = Translate.Text(ProfileResources.MobileText);
            labels.NoResultsText = Translate.Text(ProfileResources.NoResultsText);
            labels.OfficeText = Translate.Text(ProfileResources.Officetext);
            labels.TelephoneText = Translate.Text(ProfileResources.TelephoneText);
            labels.ContactInformationText = Translate.Text(ProfileResources.ContactInformationText);
            labels.Fax = Translate.Text(ProfileResources.FaxText);
            labels.Managerial = Translate.Text(ProfileResources.ManagerialText);
            labels.LineManager = Translate.Text(ProfileResources.LineManagerText);
            labels.LineManages = Translate.Text(ProfileResources.LineManagesText);
            labels.VehicleInformationSectorText = Translate.Text(ProfileResources.VehicleInformationSectionText);
            labels.LicensePlateText = Translate.Text(ProfileResources.LincesePlateText);
            labels.OfficeAdressText = Translate.Text(ProfileResources.OfficeAdressSection);
            labels.SkillsText = Translate.Text(ProfileResources.SkillsText);
            labels.ExpertiseText = Translate.Text(ProfileResources.ExpertiseText);
            labels.MangeSubscriptionsSectionText = Translate.Text(ProfileResources.ManageSubscriptionsSectiontext);
            labels.NewsFiltersText = Translate.Text(ProfileResources.NewsFiltersText);
            labels.UpdateProfilethankyouText = Translate.Text(ProfileResources.UpdatedProfileThankyouText);
            labels.UpdateProfilethankyouTitle = Translate.Text(ProfileResources.UpdatedProfileThankyouTitle);
            labels.UpdateProfilethankyouTitle = Translate.Text(ProfileResources.UpdatedProfileThankyouTitle);
            labels.UpdateProfileText = Translate.Text(ProfileResources.UpdateProfiletext);
            labels.CancelUpdateText = Translate.Text(ProfileResources.CancelProfileText);
            labels.ShowMyImageText = Translate.Text(ProfileResources.ShowMyImagetext);
            labels.ChooseImagetext = Translate.Text(ProfileResources.ChooseImageText);
            return labels;
        }

        public static SearchProfileModel GetProfile(string payid)
        {
            var cache = ProfileCacheManager.ProfileCache.ProfileSearchCache;
            if (cache == null)
                cache = new Dictionary<string, SearchProfileModel>();
            if (cache.ContainsKey(payid))
                return cache[payid];
            SearchProfileModel result = null;
            using (var context = _index.CreateSearchContext())
            {
                var query = context.GetQueryable<SearchProfileModel>();                
                query = query.Where(x => x.PayRolId == payid);


                var results = query.GetResults();
                if (results.TotalSearchResults > 0) //Acording the field payrol id should be unique
                {
                    result = results.Hits.First().Document;
                    cache.Add(payid, result);
                }
            }
            ProfileCacheManager.ProfileCache.ProfileSearchCache = cache;
            return result;

        }

        public static IEnumerable<SearchProfileModel> GetProfiles(string terms)
        {
            
            IEnumerable<SearchProfileModel> result = null;
            using (var context = _index.CreateSearchContext())
            {
                var query = context.GetQueryable<SearchProfileModel>();                
                var termpredicate = PredicateBuilder.True<SearchProfileModel>();
                termpredicate = termpredicate.BuildFilterByTerm((Profile.Models.SearchSettings)ProfileCacheManager.ProfileCache.PeopleDirectorySettings, terms, true);
                query = query.Where(termpredicate);
                var results = query.GetResults();
                if (results.TotalSearchResults > 0)
                    result = results.Hits.Take(10).Select(x => x.Document).ToList();                                    
            }
            
            return result;

        }

        public static IEnumerable<SearchProfileModel> GetSubscribedProfiles(ID targetitem)
        {

            IEnumerable<SearchProfileModel> result = null;
            using (var context = _index.CreateSearchContext())
            {
                var query = context.GetQueryable<SearchProfileModel>();
                var termpredicate = PredicateBuilder.True<SearchProfileModel>();
                termpredicate = termpredicate.FilterByPageSubscription(targetitem);
                query = query.Where(termpredicate);
                var results = query.GetResults();
                if (results.TotalSearchResults > 0)
                    result = results.Hits.Select(x => x.Document).ToList();
            }
            return result;
        }
        

    }
}