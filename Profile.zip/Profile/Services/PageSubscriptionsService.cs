﻿//-----------------------------------------------------------------------
// <copyright file="PageSubscriptionsService.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccess.Repositories;
using Glass.Mapper.Sc;
using Profile.Extensions;
using Profile.Models;
using Sitecore.Data;
using Sitecore.Globalization;
using Sitecore.Security;

namespace Profile.Services
{
    /// <summary>
    /// Summary description of PageSubscriptionsService
    /// </summary>
    public class PageSubscriptionsService
    {
        /// <summary>
        /// Holds the context
        /// </summary>
        private readonly IAuthenticationRepository _authRepo;
        private readonly ISitecoreContext _sitecore;
        private readonly UserProfile _prof;

        public PageSubscriptionsService(IAuthenticationRepository authRepo = null, ISitecoreContext sitecore = null)
        {
            _authRepo = authRepo ?? new AuthenticationRepository();
            _sitecore = sitecore ?? new SitecoreContext();
            var usr = _authRepo.GetActiveUser();
            if (usr != null)
                _prof = usr.Profile;
        }

        public UserQuickActionResult SaveItem(string id)
        {
            var popupHeader = Translate.Text("Subscription_Popup_Header");
            if (_prof != null)
            {
                var settings = _sitecore.GetItem<ProfileSubscriptionSettings>(Guid.Parse(App_GlobalResources.ProfileResources.Default_Subscription_Settings));
                if (settings != null)
                {
                    if (ID.IsID(id))
                    {
                        var result = _prof.AddOrRemovePageSubscriptions(ID.Parse(id), settings);
                        switch (result.ResultStatus)
                        {
                            case UserQuickActionResultEnum.ItemAdded:
                                _prof.Save();
                                result.PopupHeader = popupHeader;
                                result.PopupText = Translate.Text("Subscription_Add_Text");
                                break;
                            case UserQuickActionResultEnum.ItemRemoved:
                                result.PopupHeader = popupHeader;
                                result.PopupText = Translate.Text("Subscription_Remove_Text");
                                _prof.Save();
                                break;
                            case UserQuickActionResultEnum.MaxLimitReached:
                                result.PopupHeader = popupHeader;
                                result.PopupText = string.Format(settings.LimitExceededError, settings.MaxSubscribedItems.ToString());
                                break;
                            case UserQuickActionResultEnum.Error:
                                result.PopupHeader = popupHeader;
                                result.PopupText = "Unalble to perform action. Please contact administrator";
                                break;
                        }
                        return result;
                    }
                    return new UserQuickActionResult
                        {
                            ResultStatus = UserQuickActionResultEnum.Error,
                            PopupHeader = popupHeader,
                            PopupText = "The ID is not a valid ID"
                        };
                }
                return new UserQuickActionResult
                    {
                        ResultStatus = UserQuickActionResultEnum.Error,
                        PopupHeader = popupHeader,
                        PopupText = "Unable to find the subscription settings item: {847BD63E-21DC-41ED-BAD5-5BA8059A7EAA}"
                    };
            }
            return new UserQuickActionResult
                {
                    ResultStatus = UserQuickActionResultEnum.Error,
                    PopupHeader = popupHeader,
                    PopupText = "Unable to get the current profile"
                };
        }

        public IList<ID> GetSaveditems()
        {
            return _prof.GetPageSubscriptions() ?? new List<ID>();
        }

        public bool IsPageSubscribed(ID id)
        {
            bool result = false;
            if (_prof != null)
            {
                var list = _prof.GetPageSubscriptions();
                if (list != null)
                    result = list.Contains(id);
            }
            return result;
        }

        public bool IsPageSubscribed(string id)
        {
            bool result = false;
            if (_prof != null)
            {
                var list = _prof.GetPageSubscriptions();
                if (list != null)
                    result = list.Contains(ID.Parse(id));
            }
            return result;
        }
    }
}