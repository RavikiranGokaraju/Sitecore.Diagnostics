﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore;
using Sitecore.Configuration;
using Sitecore.Events;
using Sitecore.Security.Accounts;
using Profile.Extensions;

namespace Profile.Cache
{
    public class ProfileCacheManager
    {
        public static readonly ProfileCache ProfileCache = new ProfileCache(StringUtil.ParseSizeString(Settings.GetSetting("Profile.CacheMaxSize", "10MB")));        
        public void Clear(object sender, EventArgs args)
        {
            ProfileCacheManager.ProfileCache.Clear();
        }
        public void UserUpdatedorDeleted(object obj, EventArgs args)            
        {
            SitecoreEventArgs a = args as SitecoreEventArgs;
            if (a != null)
            {
                var user = a.Parameters[0] as Sitecore.Security.Accounts.MembershipUserWrapper;
                
                if (user != null)
                {
                    ProfileCacheManager.ProfileCache.ClearpersonalisedCacheForUser(user.UserName);
                    Profile.Extensions.Cache.ClearHtmlByUser(user.UserName);
                }
            }
        }
        public void ClearQuickLinks(object sender, EventArgs args)
        {
            ProfileCache.ClearAllUserQucikLinks();
        }
        public void ClearPeopleDirectorySettings(object sender, EventArgs args)
        {
            ProfileCache.ClearPeopleDirectorySettings();
        }
        public void ClearProfileSearchCache(object sender, EventArgs args)
        {
            ProfileCache.ClearProfileSearchCache();
        }
    }
}