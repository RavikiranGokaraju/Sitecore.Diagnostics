﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Profile.Models;
using Sitecore.Caching;
using Sitecore.Data;

namespace Profile.Cache
{
    /// <summary>
    /// Custom cache for different Home components
    /// </summary>
    public class ProfileCache:CustomCache
    {
        public const string QucikLinksCacheKey = "QucikLinks";
        public const string PEOPELEDIRECTORYSETTINGSCACHEKEY = "PEOPELEDIRECTORYSETTINGS";
        public const string GETPROFILECACHE = "GETPROFILECACHE";
        /// <summary>
        /// Initializes a new instance of the <see cref="ProfileCache"/> class.
        /// </summary>
        /// <param name="maxSize">The maximum size.</param>
        public ProfileCache(long maxSize) : base("Profile.Cache", maxSize) { }

        /// <summary>
        /// Gets or sets the global alerts per user
        /// </summary>
        /// <value>
        /// The global alerts.
        /// </value>
        public object this [string property]
        {
            get
            {
                return GetObject(property + Sitecore.Context.User.Name);
            }
            set
            {
                SetObject(property + Sitecore.Context.User.Name, value, 1000);
            }
        }

        public List<QuickLink> GetQucikLinks()
        {
            return (List<QuickLink>)GetObject(QucikLinksCacheKey + Sitecore.Context.User.Name);
        }

        public void SetQuickLinks(List<QuickLink> quickLinks)
        {
            SetObject(QucikLinksCacheKey + Sitecore.Context.User.Name, quickLinks, 2000);
        }


        public void Clear()
        {
            base.Clear();
        }
        public void ClearpersonalisedCacheForUser(string user)
        {
            base.RemoveKeysContaining(user);
        }
        public void ClearCachedPropertyForUser(string property)
        {
            base.RemoveKeysContaining(property + Sitecore.Context.User.Name);
        }

        public void ClearAllUserQucikLinks()
        {
            base.RemoveKeysContaining(QucikLinksCacheKey);
        }
        public void ClearPeopleDirectorySettings()
        {
            base.RemoveKeysContaining(ProfileCache.PEOPELEDIRECTORYSETTINGSCACHEKEY);
        }
        public void ClearProfileSearchCache()
        {
            base.RemoveKeysContaining(ProfileCache.GETPROFILECACHE);
        }
        public void ClearUserQuickLinks(string user)
        {
            base.Remove(QucikLinksCacheKey + user);
        }

        public ProfileDetailsSettings PeopleDirectorySettings
        {
            get
            {
                return (ProfileDetailsSettings)this[ProfileCache.PEOPELEDIRECTORYSETTINGSCACHEKEY];
            }
            set
            {
                this[ProfileCache.PEOPELEDIRECTORYSETTINGSCACHEKEY] = value;
            }
        }
        public Dictionary<string, SearchProfileModel> ProfileSearchCache
        {
            get
            {
                return (Dictionary<string, SearchProfileModel>)this[ProfileCache.GETPROFILECACHE];
            }
            set
            {
                this[ProfileCache.GETPROFILECACHE] = value;
            }
        }

    }
}