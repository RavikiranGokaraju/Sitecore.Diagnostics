﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using Base.Converter;
using Base.Models;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Security;
using Taxonomy;
using Option = Base.Models.Option;
using Sitecore.ContentSearch.Linq;
using Profile.Extensions;
using Profile.Converters;

namespace Profile.Models
{
	public class SearchProfileModel
	{
		private readonly Dictionary<string, object> fields = new Dictionary<string, object>();
		public virtual Dictionary<string, object> Fields
		{
			get
			{
				return this.fields;
			}
		}

		public virtual string this[string key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				key = key.ToLowerInvariant();
				return this.fields.ContainsKey(key) ? this.fields[key].ToString() : string.Empty;
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				this.fields[key.ToLowerInvariant()] = value;
			}
		}
		public virtual object this[ObjectIndexerKey key]
		{
			get
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				key = key.ToString().ToLowerInvariant();
				return this.fields.ContainsKey(key) ? this.fields[key] : (object)string.Empty;
			}
			set
			{
				if (key == null)
				{
					throw new ArgumentNullException("key");
				}
				this.fields[key.ToString().ToLowerInvariant()] = value;
			}
		}

		public UserProfile Profile { get; set; }

		[IndexField("businessstream")]
		public virtual string BusinessArea { get; set; }

		public string BusinessAreaLandingPageUrl
		{
			get
			{
				return !string.IsNullOrWhiteSpace(BusinessArea) && Repository.GetBusinessStreams().FirstOrDefault(x => x.ActiveDirectoryValue == BusinessArea) != null
					? Repository.GetBusinessStreams().FirstOrDefault(x => x.ActiveDirectoryValue == BusinessArea).LandingPageUrl
					: "";
			}
		}

		[IndexField("_sitecoreid")]
		public virtual string SicoreId { get; set; }

		[IndexField("office")]
		public virtual string Office { get; set; }

		[IndexField("location")]
		public virtual string Location { get; set; }

		public virtual Location OfficeLocation
		{
			get
			{
				return !string.IsNullOrWhiteSpace(Location) ? Repository.GetLocations().Where(x => x.ActiveDirectoryValue == Location).FirstOrDefault() : null;
			}
		}

		[IndexField("specialrole")]
		[TypeConverter(typeof(ProfileLandingPageConverter))]
		public virtual IEnumerable<ProfileLandingPage> SpecialRole { get; set; }

		public virtual IEnumerable<Option> SpecialRoleFullList { get; set; }

		[IndexField("role")]
		public virtual string Role { get; set; }

		public string RoleLandingPageUrl
		{
			get
			{
				return !string.IsNullOrWhiteSpace(Role) && Repository.GetRoles().FirstOrDefault(x => x.ActiveDirectoryValue == Role) != null
					? Repository.GetRoles().FirstOrDefault(x => x.ActiveDirectoryValue == Role).LandingPageUrl
					: "";
			}
		}

		[IndexField("Team")]
		public virtual string Team { get; set; }

		public string TeamLandingPageUrl
		{
			get
			{
				return !string.IsNullOrWhiteSpace(Team) && Repository.GetTeams().FirstOrDefault(x => x.ActiveDirectoryValue == Team) != null
					? Repository.GetTeams().FirstOrDefault(x => x.ActiveDirectoryValue == Team).LandingPageUrl
					: "";
			}
		}

		[IndexField("Division")]
		public virtual string Division { get; set; }

		public string DivisionLandingPageUrl
		{
			get
			{
				return !string.IsNullOrWhiteSpace(Role) && Repository.GetDivisions().FirstOrDefault(x => x.ActiveDirectoryValue == Division) != null
					? Repository.GetDivisions().FirstOrDefault(x => x.ActiveDirectoryValue == Division).LandingPageUrl
					: "";
			}
		}

		[IndexField("skills")]
		[TypeConverter(typeof(ProfileLandingPageConverter))]
		public virtual IEnumerable<ProfileLandingPage> Skills { get; set; }

		public virtual IEnumerable<Option> SkillsFullList { get; set; }

		public virtual IEnumerable<SkillsFacetGroup> SkillsFacetGroups { get; set; }

		[IndexField("Interests")]
		[TypeConverter(typeof(ProfileLandingPageConverter))]
		public virtual IEnumerable<ProfileLandingPage> Expertise { get; set; }

		public virtual IEnumerable<Option> ExpertiseFullList { get; set; }

		[IndexField("Subscriptions")]
		[TypeConverter(typeof(BasicitemTypeConverter))]
		public virtual IEnumerable<BasicSitecoreItem> Subscriptions { get; set; }

		[IndexField("PageSubscriptions")]
		[TypeConverter(typeof(BasicitemTypeConverter))]
		public virtual IEnumerable<BasicSitecoreItem> PageSubscriptions { get; set; }

		public virtual IEnumerable<Option> SubscriptionsFullList { get; set; }

		[IndexField("licenseplate")]
		public virtual string LicensePlate { get; set; }

		[IndexField("TelephoneNumber")]
		public virtual string Telephone { get; set; }

		[IndexField("VOAMobileNumber")]
		public virtual string MobileNumber { get; set; }

		[IndexField("emailadress")]
		public virtual string Email { get; set; }

		[IndexField("fullname")]
		public virtual string FullName { get; set; }

		[IndexField("portrait")]
		public virtual string Portrait { get; set; }

		[IndexField("name")]
		public virtual string Name { get; set; }

		[IndexField("status")]
		public virtual string Status { get; set; }

		[IndexField("payid")]
		public virtual string PayRolId { get; set; }

		[IndexField("ShowImage")]
		public virtual bool ShowImage { get; set; }

		[IndexField("Image")]
		public virtual string Image { get; set; }

		public virtual string GetImage(bool force = false)
		{
			return force ? Image : ShowImage ? Image : "";
		}

		public bool IsNewImage { get; set; }

		public HttpPostedFile NewImage { get; set; }

		[IndexField("Linemanager")]
		public virtual string LineManager { get; set; }

		[IndexField("DisplayName")]
		public virtual string DisplayName { get; set; }

		[IndexField("DistinguishedName")]
		public virtual string DistinguishedName { get; set; }


		public TeamStructure GetTeamStructure()
		{
			var index = ContentSearchManager.GetIndex("users");
			var teamStructure = new TeamStructure();

			using (var context = index.CreateSearchContext())
			{

				var query = context.GetQueryable<SearchProfileModel>();
				if (!string.IsNullOrEmpty(DistinguishedName))
				{
					query = query.Where(u => u.LineManager.Equals(DistinguishedName));
					var results = query.GetResults();

					if (results.TotalSearchResults > 0)
					{
						teamStructure.LineManages = results.Hits.Select(h => new ProfileLink(h.Document.DisplayName, h.Document.PayRolId)).ToList();
					}
				}

				if (!string.IsNullOrEmpty(LineManager))
				{
					query = context.GetQueryable<SearchProfileModel>();
					query = query.Where(u => u.DistinguishedName.Equals(LineManager));
					var results = query.GetResults();

					if (results.TotalSearchResults > 0)
					{
						var first = results.Hits.First();
						teamStructure.LineManager = new ProfileLink(first.Document.DisplayName, first.Document.PayRolId);
					}
				}
			}
			return teamStructure;
		}
	}
}