using Base.Models;
using Base.Models.Email;
using Glass.Mapper.Sc.Configuration.Attributes;

namespace Profile.Models
{
    public class ProfileDetailsSettings
    {
        [SitecoreField("Detailspage")]
        public virtual MiniLink DetailsPage { get; set; }

        [SitecoreField("ListingPage")]
        public virtual MiniLink ListingPage { get; set; }

        [SitecoreField("ImagePolicy")]
        public virtual Navigation ImagePolicy { get; set; }
        
        [SitecoreField("ExternalDirectoryPath")]
        public virtual string ExternalDirectoryPath { get; set; }

        [SitecoreField("MaxHeight")]
        public virtual int MaxHeight { get; set; }

        [SitecoreField("MaxWidth")]
        public virtual int MaxWidth { get; set; }

        [SitecoreField("EmailNotificationTemplate", Setting = global::Glass.Mapper.Sc.Configuration.SitecoreFieldSettings.RichTextRaw)]
        public virtual string EmailNotificationTemplate { get; set; }

        [SitecoreField]
        public virtual SmtpSettings SmtpSettings { get; set; }
    }
}