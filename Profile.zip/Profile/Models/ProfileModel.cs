﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    public class ProfileModel
    {
        public SearchProfileModel Profile { get; set; }
        public TeamStructure TeamStructure { get; set; }
        public string RequestedSitecoreid { get; set; }
        public PeopleDirectoryDisplayLabels Labels { get; set; }
        public bool EditMode { get; set; }
        public ProfileDetailsSettings Settings { get; set; }
    }
}