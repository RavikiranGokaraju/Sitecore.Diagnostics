﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{

    public class TeamStructure
    {
        public ProfileLink LineManager { get; set; }
        public List<ProfileLink> LineManages { get; set; }
    }
    public class ProfileLink
    {
        public string Name { get; set; }
        public string Payid { get; set; }

        public ProfileLink(string name, string payid)
        {
            Name = name;
            Payid = payid;
        }
    }
}