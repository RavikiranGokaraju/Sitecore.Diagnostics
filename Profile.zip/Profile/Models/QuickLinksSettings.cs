﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Glass.Mapper.Sc.Configuration.Attributes;

namespace Profile.Models
{
    [SitecoreType]
    public class QuickLinksSettings
    {
        [SitecoreField]
        public virtual int MaxQuickLinks { get; set; }
        [SitecoreField]
        public virtual string LimitExceededError { get; set; }
        [SitecoreField]
        public string SectionTitle { get; set; }
    }
}