﻿//-----------------------------------------------------------------------
// <copyright file="PageSubscriptionsModel.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    /// <summary>
    /// Summary description of PageSubscriptionsModel
    /// </summary>
    public class PageSubscriptionsModel
    {
        public ProfileSubscriptionSettings Settings { get; set; }
        public IEnumerable<SavedItem> Items { get; set; }
        public PageSubscriptionsModel() { }
    }
}