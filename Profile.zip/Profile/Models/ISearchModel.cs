﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Linq;

namespace Profile.Models
{
    public class SearchModel
    {
        public const string SearchTermName = "query";
        
        
        
        public SearchSettings Settings { get; set; }
        public string SearchTerms { get; set; }
        public PeopleDirectoryDisplayLabels Labels { get; set; }
        


        public SearchModel() { }
    }
}
