﻿//-----------------------------------------------------------------------
// <copyright file="AlertListingModel.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Base.Models;

namespace Profile.Models
{
    /// <summary>
    /// Summary description of AlertListingModel
    /// </summary>
    public class SavedForLaterModel
    {
        public SavedForLaterSettings Settings { get; set; }
        public IEnumerable<SavedItem> Items { get; set; }
        public SavedForLaterModel() { }
        
    }
}