﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using Base.Models;
using Glass.Mapper.Sc.Configuration.Attributes;
using Sitecore.ContentSearch;
using Taxonomy;

namespace Profile.Models
{
    public class SavedItem : BasePage
    {
        public Tag GetContentType
        {
            get
            {
                return ContentType == null ? null :
                    Repository.GetPageTypes()
                              .FirstOrDefault(p => p.Id.Equals(ContentType.SitecoreId.ToShortID().ToString()));
            }
        }

        [SitecoreField]
        [IndexField("ContentType")]
        [TypeConverter(typeof(TagTypeConverter))]
        public virtual Tag ContentType { get; set; }

        /// <summary>
        /// Gets or sets the template Name
        /// </summary>
        [IndexField("_templatename")]
        public virtual string TemplateName { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [SitecoreField]   
        [IndexField("Description")]
        public virtual string Description { get; set; }


        public bool IsMedia
        {
            get
            {
                return TemplateName.Equals("pdf", StringComparison.OrdinalIgnoreCase) ||
                       TemplateName.Equals("doc", StringComparison.OrdinalIgnoreCase) ||
                       TemplateName.Equals("docx", StringComparison.OrdinalIgnoreCase) ||
                       TemplateName.Equals("file", StringComparison.OrdinalIgnoreCase);
            }
        }
        public string MediaDescription
        {
            get { return string.Join(" ", MediaContent.Where(x => !x.Equals(Name)).Select(x => x.Trim())); }
        }
        /// <summary>
        /// Gets or sets the media content indexed with IFilters
        /// </summary>
        [IndexField("_content")]
        public virtual string[] MediaContent { get; set; }


    }
}