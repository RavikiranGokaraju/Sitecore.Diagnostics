﻿using System.Collections.Generic;

namespace Profile.Models
{
    public class SkillsFacetGroup
    {
        public string DisplayName { get; set; }
        public string Value { get; set; }
        public IEnumerable<FacetValueModel> Values { get; set; }
    }
}