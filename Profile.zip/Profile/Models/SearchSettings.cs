﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Base.Models;
using Base.Models.Email;
using Glass.Mapper.Sc;
using Glass.Mapper.Sc.Configuration.Attributes;
using Sitecore.Data;
using Sitecore.SecurityModel;

namespace Profile.Models
{
    [SitecoreType]
    public class SearchSettings : ProfileDetailsSettings,IEmail
    {
        [SitecoreField]
        public virtual IEnumerable<FacetModel> Facets { get; set; }

        [SitecoreField]
        public virtual bool ShowNumberOfResults { get; set; }

        [SitecoreField]
        public virtual bool FilterFacets { get; set; }

        [SitecoreField]
        public virtual string HelpText { get; set; }

        [SitecoreField]
        public virtual IEnumerable<string> Fields { get; set; }
        private List<BasicSitecoreItem> _fields;
        public virtual IEnumerable<BasicSitecoreItem> GetFields()
        {
            if (_fields == null)
            {
                _fields = new List<BasicSitecoreItem>();
                using (var corecontext = new SitecoreContext(Database.GetDatabase("core")))
                {
                    using (new SecurityDisabler())
                    {
                        foreach (var item in Fields)
                        {
                            ID fieldid = null;
                            if (ID.IsID(item))
                            {
                                fieldid = ID.Parse(item);
                                var field = corecontext.GetItem<BasicSitecoreItem>(fieldid.Guid);
                                if (field != null)
                                    _fields.Add(field);
                            }
                        }
                    }
                }
            }
            return _fields;

        }        

        [SitecoreField]
        public virtual int MaxResults { get; set; }

        [SitecoreField]
        public virtual int ResultsPerPage { get; set; }
        /// <summary>
        /// Gets or sets the order by.
        /// </summary>
        /// <value>
        /// The order by.
        /// </value>
        [SitecoreField]
        public virtual IEnumerable<string> OrderBy { get; set; }
        private List<BasicSitecoreItem> _orderby;
        public virtual IEnumerable<BasicSitecoreItem> GetOrderByItems()
        {
            if (_orderby == null)
            {
                _orderby = new List<BasicSitecoreItem>();                
                using (var corecontext = new SitecoreContext(Database.GetDatabase("core")))
                {
                    using (new SecurityDisabler())
                    {
                        foreach (var item in OrderBy)
                        {
                            ID orderid = null;
                            if (ID.IsID(item))
                            {
                                orderid = ID.Parse(item);
                                var order = corecontext.GetItem<BasicSitecoreItem>(orderid.Guid);
                                if (order != null)
                                    _orderby.Add(order);
                            }
                        }
                    }
                }
            }
            return _orderby;

        }

        public virtual int PageNumber { get; set; }

        [SitecoreField(Setting = global::Glass.Mapper.Sc.Configuration.SitecoreFieldSettings.RichTextRaw)]
        public virtual string EmailTemplate { get; set; }

        [SitecoreField]
        public virtual string EmailSubject { get; set; }

        [SitecoreField]
        public virtual string EmailFromAdress { get; set; }

        [SitecoreField]
        public virtual string EmailFromName { get; set; }

        [SitecoreField]
        public virtual bool IsHtml { get; set; }

        [SitecoreField]
        public virtual string SendNotificationTo { get; set; }
    }
}