﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Glass.Mapper.Sc.Configuration.Attributes;

namespace Profile.Models
{
    [SitecoreType]
    public class ProfileSubscriptionSettings
    {
        [SitecoreField]
        public virtual int MaxSubscribedItems { get; set; }
        [SitecoreField]
        public virtual string LimitExceededError { get; set; }
        [SitecoreField]
        public string SectionTitle { get; set; }
    }
}