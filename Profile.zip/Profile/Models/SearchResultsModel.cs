﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Profile.Models
{
    public class SearchResultsModel:SearchModel
    {
        public IEnumerable<SearchProfileModel> People { get; set; }        
    }
}