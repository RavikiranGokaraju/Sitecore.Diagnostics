﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    public class PeopleDirectoryDisplayLabels
    {        
        public string ApplyButtonText;
        public string ClearButtonText;
        public string NoResultsText;
        public string EmptySearchtermText;
        public string HeaderText;
        public string TelephoneText;
        public string MobileText;
        public string OfficeText;
        public string EmailText;
        public string ContactInformationText;
        public string Fax;
        public string Managerial;
        public string LineManager;
        public string LineManages;
        public string VehicleInformationSectorText;
        public string LicensePlateText;
        public string OfficeAdressText;
        public string SkillsText;
        public string ExpertiseText;
        public string MangeSubscriptionsSectionText;
        public string NewsFiltersText;
        public string UpdateProfilethankyouTitle;
        public string UpdateProfilethankyouText;
        public string UpdateProfileText;
        public string CancelUpdateText;
        public string ChooseImagetext;
        public string ShowMyImageText;
    }
}