﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    public class FacetValueModel
    {
        public string Value { get; set; }
        public int Count { get; set; }
        public string DisplayValue { get; set; }
        public bool Selected { get; set; }
    }
}