﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    public class SearchBarModel : SearchModel
    {
        public IEnumerable<FacetResultModel> Facets { get; set; }

        public bool EnableSkillsFacet { get; set; }

        public string SkillFacetDisplayName { get; set; }
        public string SkillFacetFieldName { get; set; }

        public IEnumerable<SkillsFacetGroup> SkillsFacetGroups {get;set;}
    }
}