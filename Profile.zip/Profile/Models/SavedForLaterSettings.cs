﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using Base.Models;
using Glass.Mapper.Sc.Configuration.Attributes;


namespace Profile.Models
{
    /// <summary>
    /// Set of configuration settings of the Global Alerts components
    /// </summary>
    [SitecoreType(TemplateId = "{4BF0526A-5C34-4D6B-BA7C-B5820ADB6BAD}")]
    public class SavedForLaterSettings
    {        
        [SitecoreField("SectionTitle")]        
        public string SectionTitle { get; set; }

        [SitecoreField("ListingPage")]        
        public virtual MiniLink ListingPage { get; set; }
        
        [SitecoreField]
        public virtual int MaxSavedItems { get; set; }

        [SitecoreField]
        public virtual string LimitExceededError { get; set; }
    }
}