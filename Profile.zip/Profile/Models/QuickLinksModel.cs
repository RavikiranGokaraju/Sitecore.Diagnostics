﻿//-----------------------------------------------------------------------
// <copyright file="QuickLinksModel.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    /// <summary>
    /// Summary description of QuickLinksModel
    /// </summary>
    public class QuickLinksModel
    {
        public IEnumerable<QuickLink> QuickLinks { get; set; }
    }

    public class QuickLink
    {
        public string Title { get; set; }
        public string Url { get; set; }
        public bool IsExternal { get; set; }
        public string Id { get; set; }
        public bool IsDefaultLink { get; set; }
        public bool HideDefaultLink { get; set; }
    }
}