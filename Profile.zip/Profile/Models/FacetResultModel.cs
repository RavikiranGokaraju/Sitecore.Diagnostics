﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
    public class FacetResultModel
    {
        public string DisplayName { get; set; }
        public string FieldName { get; set; }
        public IEnumerable<FacetValueModel> Values { get; set; }

    }
}