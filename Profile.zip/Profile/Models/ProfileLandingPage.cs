﻿using Base.Models;
using Glass.Mapper.Sc.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Models
{
	[SitecoreType]
	public class ProfileLandingPage : BasicSitecoreItem
	{
		[SitecoreField]
		public virtual MiniLink LandingPage { get; set; }
	}
}