﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Extensions
{
    public static class StringExtensions
    {
        public static string GetPayRolId(this string payrolid)
        {
            string lowerInvariant = payrolid;
            if (lowerInvariant.IndexOf(",") > 0)
            {
                lowerInvariant = lowerInvariant.Split(',')[0];
            }
            else if (payrolid.IndexOf("\\") > 0)
            {
                lowerInvariant = lowerInvariant.Split('\\')[1];
            }
            lowerInvariant = lowerInvariant.ToLowerInvariant();
            return lowerInvariant;
        }

        public static string GetCommonName(string displayName)
        {
            return string.Format("CN={0},OU=VOA,DC=voa,DC=qa", displayName);
        }

        public static string GetDisplayName(string commonName)
        {
            return !string.IsNullOrEmpty(commonName) ? commonName.Split(',').First().Replace("CN=", "").Trim() : "";
        }
    }
}