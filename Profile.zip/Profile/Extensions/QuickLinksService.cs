﻿//-----------------------------------------------------------------------
// <copyright file="QuickLinksHelper.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Glass.Mapper.Sc;
using Newtonsoft.Json;
using Profile.Cache;
using Profile.Models;
using Sitecore.Globalization;

namespace Profile.Extensions
{
    /// <summary>
    /// Summary description of QuickLinksHelper
    /// </summary>
    public static class QuickLinksService
    {
        private static ISitecoreContext _sitecore;
        private static ISitecoreContext Sitecore
        {
            get
            {
                if(_sitecore == null)
                    _sitecore = new SitecoreContext();
                return _sitecore;
            }
        }
        public static List<QuickLink> GetUserQuickLinks(Sitecore.Security.Accounts.User user)
        {
            var result = ProfileCacheManager.ProfileCache.GetQucikLinks();
            if (result != null && result.Any())
                return result;

            result = new List<QuickLink>();
            var defaultUserLinks = GetDefaultUserLinks(user);
            var quickLinksJson = user.Profile.GetQuickLinksJson();
            var userLinksUpdated = false;
            if (string.IsNullOrWhiteSpace(quickLinksJson))
            {
                userLinksUpdated = true;
                result.AddRange(defaultUserLinks);
            }
            else
            {
                result.AddRange(JsonConvert.DeserializeObject<List<QuickLink>>(quickLinksJson));
                foreach (var defaultUserLink in defaultUserLinks)
                {
                    if (!result.Exists(r => r.Id == defaultUserLink.Id))
                    {
                        userLinksUpdated = true;
                        result.Add(defaultUserLink);
                    }
                }
            }

            if (userLinksUpdated)
            {
                user.Profile.SetQuickLinksJson(JsonConvert.SerializeObject(result));
                ProfileCacheManager.ProfileCache.SetQuickLinks(result);
                user.Profile.Save();
            }

            return result;
        }

        public static bool ItemInUsersQuickLinks(Sitecore.Security.Accounts.User user, string id)
        {
            var currentLinks = GetUserQuickLinks(user);
            var existingIndex = currentLinks.FindIndex(c => c.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

            return existingIndex != -1;
        }

        public static UserQuickActionResult AddOrUpdateUserQuickLink(Sitecore.Security.Accounts.User user, QuickLink quickLink, bool deleteIfExists = false)
        {
            var popupHeader = Translate.Text("Quick_Links_Popup_Header");
            var result = new UserQuickActionResult{PopupHeader = popupHeader};
            if (!string.IsNullOrWhiteSpace(quickLink.Url) && !string.IsNullOrWhiteSpace(quickLink.Title))
            {
                var currentLinks = GetUserQuickLinks(user);
                var settings = Sitecore.GetItem<ProfileSubscriptionSettings>(Guid.Parse(App_GlobalResources.ProfileResources.Default_QuickLinks_Settings));
                if (currentLinks.Count >= settings.MaxSubscribedItems)
                {
                    result.ResultStatus = UserQuickActionResultEnum.MaxLimitReached;
                    result.PopupText = string.Format(settings.LimitExceededError, settings.MaxSubscribedItems);
                    return result;
                }
                var existingIndex = currentLinks.FindIndex(c => c.Id.Equals(quickLink.Id, StringComparison.OrdinalIgnoreCase));

                if (existingIndex == -1)
                {
                    currentLinks.Add(quickLink);
                    result.PopupText = Translate.Text("Quick_Links_Add_Text");
                    result.ResultStatus = UserQuickActionResultEnum.ItemAdded;
                }
                else
                {
                    if (deleteIfExists)
                    {
                        currentLinks.RemoveAll(l => l.Id.Equals(quickLink.Id, StringComparison.OrdinalIgnoreCase));
                        result.PopupText = Translate.Text("Quick_Links_Remove_Text");
                        result.ResultStatus = UserQuickActionResultEnum.ItemRemoved;
                    }
                    else
                    {
                        currentLinks[existingIndex].Title = quickLink.Title;
                        currentLinks[existingIndex].Url = quickLink.Url;
                        result.PopupText = Translate.Text("Quick_Links_Exists");
                        result.ResultStatus = UserQuickActionResultEnum.ItemExists;
                    }
                }

                ProfileCacheManager.ProfileCache.SetQuickLinks(currentLinks);
                user.Profile.SetQuickLinksJson(JsonConvert.SerializeObject(currentLinks));
                user.Profile.Save();
            }
            else
                throw new Exception("Link url and title are mandatory");

            return result;
        }

        public static void DeleteUserQuickLink(Sitecore.Security.Accounts.User user, string id)
        {
            var currentLinks = GetUserQuickLinks(user);
            var existingIndex = currentLinks.FindIndex(c => c.Id.Equals(id));

            if (existingIndex != -1)
            {
                if (currentLinks[existingIndex].IsDefaultLink)
                    currentLinks[existingIndex].HideDefaultLink = true;
                else
                    currentLinks.RemoveAt(existingIndex);

                ProfileCacheManager.ProfileCache.SetQuickLinks(currentLinks);
                user.Profile.SetQuickLinksJson(JsonConvert.SerializeObject(currentLinks));
                user.Profile.Save();
            }
        }

        public static void UpdatedQuickLinksSortOrder(Sitecore.Security.Accounts.User user, List<string> ids)
        {
            var currentLinks = GetUserQuickLinks(user);
            var updatedLinks = ids.Select(id => currentLinks.First(f => f.Id.Equals(id, StringComparison.OrdinalIgnoreCase))).ToList();
            ProfileCacheManager.ProfileCache.SetQuickLinks(updatedLinks);
            user.Profile.SetQuickLinksJson(JsonConvert.SerializeObject(updatedLinks));
            user.Profile.Save();
        }

        /// <summary>
        /// Gets the default links based on users business stream.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns></returns>
        private static IEnumerable<QuickLink> GetDefaultUserLinks(Sitecore.Security.Accounts.User user)
        {
            var result = new List<QuickLink>();
            var userBusinessStream = user.Profile.GetBusinessStream();
            if (!string.IsNullOrWhiteSpace(userBusinessStream))
            {
                var businessStream =
                    Taxonomy.Repository.GetBusinessStreams()
                            .FirstOrDefault(b => b.ActiveDirectoryValue.Equals(userBusinessStream));
                if (businessStream != null)
                {
                    var defaultLinks = businessStream.DefaultLinks;
                    result =
                        defaultLinks.Select(
                            d =>
                            new QuickLink
                            {
                                Title = d.Title,
                                Url = d.Url,
                                IsExternal = d.IsExternal,
                                IsDefaultLink = true,
                                Id = d.Id
                            }).ToList();
                }
            }
            return result;
        }
    }
}