﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore;
using Sitecore.Caching;
using Sitecore.Sites;

namespace Profile.Extensions
{
    public static class Cache
    {
        public static void ClearHtmlByUser(this Sitecore.Security.UserProfile prof)
        {
            ClearHtmlByUser(prof.UserName);
        }
        public static void ClearHtmlByUser(string username)
        {
            using (new SiteContextSwitcher(SiteContextFactory.GetSiteContext("website")))
            {
                var cache = CacheManager.GetHtmlCache(Context.Site);
                if (cache != null)
                    cache.RemoveKeysContaining(string.Concat("_#user:", username));
            }
        }
    }
}