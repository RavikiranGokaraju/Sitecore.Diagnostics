﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;
using System.Xml.Serialization;
using Base.Models;
using Profile.Cache;
using Sitecore.Data;
using Taxonomy;

namespace Profile.Extensions
{
    /// <summary>
    /// base class to work with user properties, synchronizing the values with the session to avoid reading continuosly from the DB.
    /// </summary>
    public static class User
    {

        public const string BusinessStream = "BusinessStream";
        public const string Subscription = "Subscriptions";
        public const string Role = "Role";
        public const string Location = "Location";
        public const string SelectedWidgetClasses = "SelectedWidgetClasses";
        public const string QuickLinks = "QuickLinks";
        public const string PAYID = "PayID";
        public const string STATUS = "Status";
        public const string LICENSEPLATE = "LicensePlate";
        public const string SPECIALROLE = "SpecialRole";
        public const string SUBSCRIPTIONS = "Subscriptions";
        public const string IMAGE = "Image";
        public const string FIRSTNAME = "FirstName";
        public const string LASTNAME = "LastName";
        public const string SHOWIMAGE = "ShowImage";
        public const string SKILLS = "Skills";
        public const string INTERESTS = "Interests";
        public const string TELEPHONENUMBER = "TelephoneNumber";
        public const string MOBILENUMBER = "VOAMobileNumber";


        public static string GetFirstName(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, FIRSTNAME);            
        }
        public static string GetLastName(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, LASTNAME);
        }
        public static string GetBusinessStream(this Sitecore.Security.UserProfile prof)
        {            
            return GetProperty<string>(prof, BusinessStream);
        }
        public static string GetBusinessStreams(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, BusinessStream)   + "|" +  GetProperty<string>(prof, Subscription);
        }
        public static void SetSubscriptions(this Sitecore.Security.UserProfile prof, string subscriptions)
        {
            if (prof != null)
            {
                SetProperty(prof, SUBSCRIPTIONS, subscriptions);
            }
        }
        public static void SetSkills(this Sitecore.Security.UserProfile prof, string skills)
        {
            if (prof != null)
            {
                SetProperty(prof, SKILLS, skills);
            }
        }
        public static void SetExpertise(this Sitecore.Security.UserProfile prof, string expertise)
        {
            if (prof != null)
            {
                SetProperty(prof, INTERESTS, expertise);
            }
        }
        public static string GetRole(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, Role);
        }
        public static string GetLocation(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, Location);
        }
        public static string GetWidgetClassesCsv(this Sitecore.Security.UserProfile prof)
        {
            string savedwidgets = prof[SelectedWidgetClasses];   
            if (string.IsNullOrWhiteSpace(savedwidgets))
            {
                var userbs = prof.GetBusinessStreams().Split('|').Where(s => !String.IsNullOrWhiteSpace(s) && ID.IsID(s)).Select(s => ID.Parse(s));
                var userbsstrs = prof.GetBusinessStreams().Split('|').Where(s => !String.IsNullOrWhiteSpace(s) && !ID.IsID(s));                
                var bs = Repository.GetBusinessStreams().Where(x => userbsstrs.Contains(x.ActiveDirectoryValue) || userbs.Contains(x.SitecoreId));
                IEnumerable<Widget> allwidgets = bs.Where(x=>x.DefaultWidgets!= null && x.DefaultWidgets.Any()).SelectMany(x => x.DefaultWidgets);
                if (allwidgets != null && allwidgets.Any())
                {
                    IEnumerable<Widget> distinctwidgets = allwidgets.Distinct();
                    if (distinctwidgets != null && distinctwidgets.Any())
                    {
                        ProfileCacheManager.ProfileCache[SelectedWidgetClasses] = string.Join(",", distinctwidgets.Select(w => w.CssClass));
                        savedwidgets = GetProperty<string>(prof, SelectedWidgetClasses);
                    }
                }
            }
            
            return savedwidgets;
            
            
        }
        public static string GetQuickLinksJson(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, QuickLinks);
        }
        public static void SetQuickLinksJson(this Sitecore.Security.UserProfile prof, string quickLinksJson)
        {
            if (prof != null)
            {
                SetProperty(prof, QuickLinks, quickLinksJson);
            }
        }
        public static void SetWidgetClassesCsv(this Sitecore.Security.UserProfile prof, string widgetClassesCsv)
        {
            if (prof != null)
            {
                SetProperty(prof, SelectedWidgetClasses, widgetClassesCsv);
            }
        }
        public static string GetPayId(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, PAYID);
        }
        public static void SetPayId(this Sitecore.Security.UserProfile prof, int payid)
        {
            if (prof != null)
            {
                SetProperty(prof, PAYID, payid);
            }
        }
        public static string GetStatus(this Sitecore.Security.UserProfile prof)
        {
            return GetProperty<string>(prof, STATUS);
        }
        public static string GetImage(this Sitecore.Security.UserProfile prof)
        {
            return prof.GetShowImage() ? GetProperty<string>(prof, IMAGE) : "";
        }
        public static bool GetShowImage(this Sitecore.Security.UserProfile prof)
        {
            bool result = false;
            string tmp = GetProperty<string>(prof, SHOWIMAGE);
            if (!string.IsNullOrEmpty(tmp))
            {
                result = tmp == "1";
            }
            return result;
        }
        public static void SetShowImage(this Sitecore.Security.UserProfile prof, bool show)
        {
            if (prof != null)
            {
                SetProperty(prof, SHOWIMAGE, show ? "1" : "0");
            }
        }

        public static void SetStatus(this Sitecore.Security.UserProfile prof, string status)
        {
            if (prof != null)
            {
                SetProperty(prof, STATUS, status);
            }
        }
        public static void SetLicensePlate(this Sitecore.Security.UserProfile prof, string LicensePlate)
        {
            if (prof != null)
            {
                SetProperty(prof, LICENSEPLATE, LicensePlate);
            }
        }

        public static void SetContactNumbers(this Sitecore.Security.UserProfile prof, string telephoneNumber, string mobileNumber)
        {
            if (prof != null)
            {
                SetProperty(prof, TELEPHONENUMBER, telephoneNumber);
                SetProperty(prof, MOBILENUMBER, mobileNumber);
            }
        }
        public static void SetSpecialRole(this Sitecore.Security.UserProfile prof, string SpecialRole)
        {
            if (prof != null)
            {
                SetProperty(prof, SPECIALROLE, SpecialRole);
            }
        }        

        /// <summary>
        /// Gets the property.
        /// </summary>
        /// <param name="prof">The profile.</param>
        /// <param name="property">The property name.</param>
        /// <returns>The value from the session if exist, otherwise tries to load it from the DB (via profile)</returns>
        public static T GetProperty<T>(Sitecore.Security.UserProfile prof, string property) where T : class
        {
            object tmp = ProfileCacheManager.ProfileCache[property];
            if (tmp == null)
            {
                string value = prof[property];
                if (!String.IsNullOrWhiteSpace(value))
                {
                    // Only de-serialize if T is not string.
                    tmp = value as T;
                    if(tmp == null)
                        tmp = typeof (T) == typeof(string) ? (object)value : DeSerializeFromString<T>(value);
                    ProfileCacheManager.ProfileCache[property] = tmp;
                }
                //object value = prof.GetPropertyValue(property);
                //if (value!= null)
                //{
                //    ProfileCacheManager.ProfileCache[property] = value;
                //}
            }
            tmp = tmp as T;            
            return (T)tmp;
        }

        /// <summary>
        /// Sets the property in the session and then stores it in the DB (Via profile.save)
        /// </summary>
        /// <param name="prof">The profile.</param>
        /// <param name="property">The property anme.</param>
        /// <param name="value">The value.</param>
        public static void SetProperty(Sitecore.Security.UserProfile prof, string property, object value)
        {            
            //if the value is empty, remveve the cache and the property
            if (((value is string) && string.IsNullOrWhiteSpace((string)value)) || value == null)
            {
                prof.RemoveCustomProperty(property);
                ProfileCacheManager.ProfileCache.ClearCachedPropertyForUser(property);

            }
            else
            {
                // Only serialize if value is not string.
                var tmp = value is string ? (string)value : Serialize(value);
                ProfileCacheManager.ProfileCache[property] = value;
                prof[property]= tmp;
            }
            //prof.Save();
        }
        private static string Serialize<T>(T toSerilize)
        {
            //XmlSerializer xmlSerializer = new XmlSerializer(toSerilize.GetType());

            //using (StringWriter textWriter = new StringWriter())
            //{
            //    xmlSerializer.Serialize(textWriter, toSerilize);
            //    return textWriter.ToString();
            //}
            string invariantString;
            MemoryStream memoryStream = new MemoryStream();
            try
            {
                (new BinaryFormatter()).Serialize(memoryStream, toSerilize);
                invariantString = Convert.ToBase64String(memoryStream.ToArray());
                return invariantString;
            }
            finally
            {
                memoryStream.Close();
            }
        }
        private static T DeSerializeFromString<T>(string value)
        {
            //XmlSerializer serializer = new XmlSerializer(typeof(T));

            //using (StringReader reader = new StringReader(xml))
            //{
            //    return (T)serializer.Deserialize(reader);
            //}
            object obj;            
            if (value == null || value.Length < 1)
            {
                return default(T);
            }
            byte[] numArray = Convert.FromBase64String(value);
            MemoryStream memoryStream = null;
            try
            {
                memoryStream = new MemoryStream(numArray);
                obj = (new BinaryFormatter()).Deserialize(memoryStream);
            }
            finally
            {
                if (memoryStream != null)
                {
                    memoryStream.Close();
                }
            }
            return (T)obj;
        }
    }
}