﻿//-----------------------------------------------------------------------
// <copyright file="PageSubscriptionsExtensions.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Profile.Models;
using Sitecore.Data;

namespace Profile.Extensions
{
    /// <summary>
    /// Summary description of PageSubscriptionsExtensions
    /// </summary>
    public static class PageSubscriptionsExtensions
    {
        public const string PageSubscriptions = "PageSubscriptions";

        /// <summary>
        /// Gets the viewed alerts.
        /// </summary>
        /// <param name="prof">The prof.</param>
        /// <returns></returns>
        public static IList<ID> GetPageSubscriptions(this Sitecore.Security.UserProfile prof)
        {
            return User.GetProperty<IList<ID>>(prof, PageSubscriptions);
        }


        /// <summary>
        /// Adds the viewed alert.
        /// </summary>
        /// <param name="prof">The prof.</param>
        /// <param name="newId">The ealert identifier.</param>
        public static UserQuickActionResult AddOrRemovePageSubscriptions(this Sitecore.Security.UserProfile prof, ID newId, ProfileSubscriptionSettings settings)
        {
            var result = new UserQuickActionResult();
            var tmp = (List<ID>)prof.GetPageSubscriptions() ?? new List<ID>(1);
            if (!ID.IsNullOrEmpty(newId))
            {
                if (!tmp.Contains(newId))
                {
                    if (tmp.Count < settings.MaxSubscribedItems)
                    {
                        tmp.Add(newId);
                        result.ResultStatus = UserQuickActionResultEnum.ItemAdded;
                    }
                    else
                        result.ResultStatus = UserQuickActionResultEnum.MaxLimitReached;
                }
                else
                {
                    tmp.Remove(newId);
                    result.ResultStatus = UserQuickActionResultEnum.ItemRemoved;
                }

                User.SetProperty(prof, PageSubscriptions, tmp);
                //We don't need to clear caches objects,
                //as there are event handlers which will trigger the same action. This is usefull for changes in the back end                
            }
            return result;
        }
    }
}