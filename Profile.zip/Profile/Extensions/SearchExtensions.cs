﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using Profile.Models;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Base.Models;
using Glass.Mapper.Sc;
using Sitecore.Data;

namespace Profile.Extensions
{
    public static class SearchExtensions
    {

        public static Expression<Func<SearchProfileModel, Boolean>> BuildFilter(this Expression<Func<SearchProfileModel, Boolean>> predicate, Models.SearchSettings settings,string terms)
        {
            var profilepredicate = PredicateBuilder.True<SearchProfileModel>();            
            var termpredicate = PredicateBuilder.True<SearchProfileModel>();

            if (settings != null)
            {
                if (settings.Facets != null && settings.Facets.Any())
                {

                    foreach (var item in settings.Facets)
                    {
                        
                        if (!string.IsNullOrWhiteSpace(item.Searchvalue))
                        {
                            List<string> valuelist = item.Searchvalue.Split('|').Select(s => s.Trim()).ToList();
                            if (valuelist.Any())
                            {
                                var facetpredicate = PredicateBuilder.False<SearchProfileModel>();
                                foreach (var value in valuelist)
                                {
                                    facetpredicate = facetpredicate.Or(x => x[(ObjectIndexerKey)item.FieldName] == value);
                                }
                                profilepredicate = profilepredicate.And(facetpredicate);
                            }
                            
                        }
                    }

                }
                termpredicate = termpredicate.BuildFilterByTerm(settings, terms);

                
            }            
            predicate  = predicate.Or(profilepredicate);
            predicate = predicate.And(termpredicate);
            return predicate;
        }

        public static Expression<Func<SearchProfileModel, Boolean>> FilterByPageSubscription(this Expression<Func<SearchProfileModel, Boolean>> predicate, ID targetItem)
        {
            var profilepredicate = PredicateBuilder.True<SearchProfileModel>();
            if (!ID.IsNullOrEmpty(targetItem))
            {
                string id = targetItem.ToShortID().ToString().ToLowerInvariant();
                if (targetItem != ID.Null)
                {
                    profilepredicate = profilepredicate.And(x => (string)x[(ObjectIndexerKey)"PageSubscriptions"] == id);
                }
                predicate = predicate.And(profilepredicate);
            }
            return predicate;
        }

        public static Expression<Func<SearchProfileModel, Boolean>> BuildFilterByTerm(this Expression<Func<SearchProfileModel, Boolean>> predicate, Models.SearchSettings settings, string terms, bool startsWithTerm = false)
        {
             var termpredicate = PredicateBuilder.True<SearchProfileModel>();
             if (settings != null)
             {
                 if (settings.GetFields() != null && settings.GetFields().Any() && !string.IsNullOrWhiteSpace(terms))
                 {
                     List<string> termslist = terms.Split(' ').Select(s => s.Trim()).ToList();
                     foreach (var field in settings.GetFields())
                     {
                         foreach (var term in termslist)
                         {
                             termpredicate = startsWithTerm
                                                 ? termpredicate.Or(
                                                     x => ((string) x[(ObjectIndexerKey) field.Name]).StartsWith(term))
                                                 : termpredicate.Or(
                                                     x => ((string) x[(ObjectIndexerKey) field.Name]).Contains(term));
                         }
                     }
                 }
             }
             else
             {
                 List<string> termslist = terms.Split(' ').Select(s => s.Trim()).ToList();
                 foreach (var field in new string[] { "firstname", "lastname" })
                 {
                     foreach (var term in termslist)
                     {
                         termpredicate = termpredicate.Or(x => ((string)x[(ObjectIndexerKey)field]).Contains(term));
                     }
                 }

             }
             return termpredicate;
        }

        public static IQueryable<SearchProfileModel> FacetOnProfile(this IQueryable<SearchProfileModel> predicate, Models.SearchSettings settings)
        {            
             if (settings != null)
            {
                if (settings.Facets != null && settings.Facets.Any())
                {
                    foreach (var item in settings.Facets)
                    {
                        if (!string.IsNullOrWhiteSpace(item.FieldName))
                        {
                            predicate = predicate.FacetOn(x => x[(ObjectIndexerKey)item.FacetFieldName]);
                        }
                    }
                    
                }
             }            

            return predicate;

        }

        public static IQueryable<SearchProfileModel> ApplyOrder(this IQueryable<SearchProfileModel> predicate, Models.SearchSettings settings, ISitecoreContext context)
        {
            if (settings != null)
            {
               
                    bool firstclause = true; ;
                    foreach (var item in settings.GetOrderByItems())
                    {
                        if (!string.IsNullOrWhiteSpace(item.Name))
                        {
                            if (firstclause)
                            {
                                predicate = predicate.OrderBy(x => x[(ObjectIndexerKey)item.Name]);
                                firstclause = false;
                            }
                            else
                                predicate = ((IOrderedQueryable<SearchProfileModel>)predicate).ThenBy(x => x[(ObjectIndexerKey)FacetModel.GetFacetFieldName(item.Name)]);
                                //we use the faciet field because it is not analyzed, so it's orderable. Analyzed fields are tokenized, so are not orderable
                        }
                    }

               
            }

            return predicate;

        }

        public static IEnumerable<FacetResultModel> CleanUpFacets(this FacetResults facets, Models.SearchSettings settings,ISitecoreContext context)
        {
            List<FacetResultModel> result = new List<FacetResultModel>();
            if (settings != null && settings.Facets != null && settings.Facets.Any())
            {
                foreach (FacetModel facet in settings.Facets.Where(f => f != null && !f.FieldName.Equals("Skills", StringComparison.OrdinalIgnoreCase)))
                {
                    FacetResultModel facetresult = new FacetResultModel();
                    facetresult.DisplayName = facet.DisplayName;
                    facetresult.FieldName = facet.FieldName;
                    List<string> searchvalues = new List<string>();
                    if(!string.IsNullOrWhiteSpace(facet.Searchvalue))
                        searchvalues = facet.Searchvalue.Split('|').ToList();
                    var values = new List<FacetValueModel>();
                    if (facets != null)
                    {
                        var facetcategory = facets.Categories.FirstOrDefault(f => string.Equals(f.Name, facet.FacetFieldName, StringComparison.InvariantCultureIgnoreCase));
                        if (facetcategory != null)
                        {
                            if (facet.DataSource == null)
                            {
                                foreach (var value in facetcategory.Values.Where(v => v != null && !String.IsNullOrWhiteSpace(v.Name) ))
                                {
                                    FacetValueModel valueResult = new FacetValueModel();
                                    valueResult.Count = value.AggregateCount;
                                    valueResult.Value = value.Name;
                                    valueResult.DisplayValue = settings.ShowNumberOfResults ? valueResult.Value + " (" + valueResult.Count.ToString() + ")" : valueResult.Value;
                                    valueResult.Selected = searchvalues.Contains(valueResult.Value);
                                    values.Add(valueResult);
                                }
                            }
                            else
                            {
                                var kids = facet.DataSource.StandardChildren;
                                foreach (var value in kids.Where(v => v != null))
                                {
                                    FacetValueModel valueResult = new FacetValueModel();                        
                                    var facetedvalue = facetcategory.Values.Where(x=>x.Name == value.Id.ToString()).FirstOrDefault();
                                    if(facetedvalue !=null)
                                        valueResult.Count = facetedvalue.AggregateCount;
                                    valueResult.Value = new ID(value.Id).ToShortID().ToString();
                                    string displayvalue = string.IsNullOrWhiteSpace(value.DisplayName) ? value.Name : value.DisplayName;
                                    valueResult.DisplayValue = settings.ShowNumberOfResults ? displayvalue + " (" + valueResult.Count.ToString() + ")" : displayvalue;
                                    valueResult.Selected = searchvalues.Contains(valueResult.Value);
                                    values.Add(valueResult);
                                }
                            }                            
                        }
                    }
                    facetresult.Values = values;
                    result.Add(facetresult);
                }                     
            }
            return result;
        }

     
    }
}