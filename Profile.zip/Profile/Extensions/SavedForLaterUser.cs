﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Profile.Extensions;
using Profile.Models;
using Sitecore.Data;

namespace Profile.Extensions
{
    public static class SavedForLaterUser
    {
        /// <summary>
        /// The viewed alerts
        /// </summary>
        public const string SavedItems = "Saveditems";

        /// <summary>
        /// Gets the viewed alerts.
        /// </summary>
        /// <param name="prof">The prof.</param>
        /// <returns></returns>
        public static IList<ID> GetSavedItems(this Sitecore.Security.UserProfile prof)
        {
            return (IList<ID>)User.GetProperty<IList<ID>>(prof, SavedForLaterUser.SavedItems);
        }


        /// <summary>
        /// Adds the viewed alert.
        /// </summary>
        /// <param name="prof">The prof.</param>
        /// <param name="newId"></param>
        /// <param name="settings"></param>
        public static UserQuickActionResult AddOrRemoveSavedItems(this Sitecore.Security.UserProfile prof, ID newId, SavedForLaterSettings settings)
        {
            var result = new UserQuickActionResult();
            var tmp = (List<ID>)prof.GetSavedItems() ?? new List<ID>(1);
            if (!ID.IsNullOrEmpty(newId))
            {
                if (!tmp.Contains(newId))
                {
                    if (tmp.Count < settings.MaxSavedItems)
                    {
                        tmp.Add(newId);
                        result.ResultStatus = UserQuickActionResultEnum.ItemAdded;
                    }
                    else
                        result.ResultStatus = UserQuickActionResultEnum.MaxLimitReached;
                }
                else
                {
                    tmp.Remove(newId);
                    result.ResultStatus = UserQuickActionResultEnum.ItemRemoved;
                }

                User.SetProperty(prof, SavedItems, tmp);
                //We don't need to clear caches objects,
                //as there are event handlers which will trigger the same action. This is usefull for changes in the back end
            }
            return result;
        }
    }
}