﻿//-----------------------------------------------------------------------
// <copyright file="UserQuickActionResult.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Profile.Extensions
{
    /// <summary>
    /// Summary description of UserQuickActionResult
    /// </summary>
    public class UserQuickActionResult
    {
        public UserQuickActionResultEnum ResultStatus { get; set; }
        public string PopupHeader { get; set; }
        public string PopupText { get; set; }
    }

    public enum UserQuickActionResultEnum
    {
        ItemAdded,
        ItemRemoved,
        MaxLimitReached,
        Error,
        ItemExists
    }
}