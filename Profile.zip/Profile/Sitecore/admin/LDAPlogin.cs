﻿using LightLDAP.Configurations;
using Sitecore;
using Sitecore.Collections;
using Sitecore.Configuration;
using Sitecore.Diagnostics;
using Sitecore.Security;
using Sitecore.Security.Accounts;
using Sitecore.Security.Authentication;
using Sitecore.Security.Domains;
using Sitecore.Text;
using Sitecore.Web;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Sitecore.Pipelines;
using Sitecore.Pipelines.LoggedIn;
using Sitecore.Web.Authentication;
using Sitecore.Shell.Applications.ContentEditor;

namespace Profile.sitecore.Admin
{
    public class LDAPLogin : Page
    {
        private bool isDebug;

        private string loginError;

        private string userToLogin;

        protected HtmlForm form1;

        public LDAPLogin()
        {
        }

        private void DoLogin(string username)
        {
            if (!AuthenticationManager.Provider.Login(username, true))
            {
                this.loginError = string.Format("Can't login a user '{0}'", username);
                Log.Warn(this.loginError, this);
                return;
            }
            Log.Debug("LDAP: Authenticated:" + username, this);
            User user = Sitecore.Security.Accounts.User.FromName(username, true);
            string startUrl = this.GetStartUrl(user);
            //LoggedInArgs loggedInArg = new LoggedInArgs()
            //{
            //    Username = AuthenticationManager.GetActiveUser().Name,
            //    StartUrl = startUrl,
            //    Persist = true
            //};
            ////Pipeline.Start("loggedin", loggedInArg);
            //AddCookie(loggedInArg);
            Log.Debug("LDAP: Redirecting to:" + startUrl, this);
            WebUtil.Redirect(startUrl);
        }

        private void AddCookie(LoggedInArgs args)
        {
            Log.Debug("LDAP: Add cookie started", this);
            Assert.ArgumentNotNull((object)args, "args");
            string ticket = TicketManager.CreateTicket(args.Username, args.StartUrl, args.Persist);
            Log.Debug("LDAP: created authentication ticket", this);

            if (string.IsNullOrEmpty(ticket))
                return;
            HttpContext current = HttpContext.Current;
            Log.Debug("LDAP: Context current read", this);

            if (current == null)
                return;
            HttpCookie cookie = new HttpCookie("sitecore_userticket", ticket)
            {
                HttpOnly = true,
                Expires = args.Persist ? System.DateTime.Now.Add(Sitecore.Configuration.Settings.Authentication.ClientPersistentLoginDuration) : System.DateTime.MinValue
            };
            current.Response.AppendCookie(cookie);
            Log.Debug("LDAP: cookie added", this);


            RecentDocuments.CleanupUserProfile(args.Username);
            Log.Debug("Cleaning up user profile", this);

        }


        private bool DomainExists(string domainName)
        {
            return Domain.GetDomain(domainName) != null;
        }

        //private string[] GetFullMembership(string userToLogin)
        //{
        //    List<string> strs = new List<string>();
        //    string[] rolesForUser = Roles.GetRolesForUser(userToLogin);
        //    if (rolesForUser == null || (int)rolesForUser.Length == 0)
        //    {
        //        return strs.ToArray();
        //    }
        //    strs.AddRange(rolesForUser);
        //    if (RolesInRolesManager.RolesInRolesSupported())
        //    {
        //        RoleList roleList = RolesInRolesManager.GetRolesForUser(User.FromName(userToLogin, false), true) as RoleList;
        //        if (roleList != null && roleList.Count() > 0)
        //        {
        //            foreach (Role role in roleList)
        //            {
        //                if (strs.Contains(role.Name()))
        //                {
        //                    continue;
        //                }
        //                strs.Add(string.Format("<{0}>", role.Name()));
        //            }
        //        }
        //    }
        //    return strs.ToArray();
        //}

        private string GetStartUrl(User user)
        {
            var originalUrl = Session["redirectUrl"].ToString();

            if (!string.IsNullOrEmpty(originalUrl))
            {
                Log.Debug("LDAP: Found session url:" + originalUrl, this);
                return originalUrl;
            }
            Log.Debug("LDAP: Not Found session url", this);
            string cookieValue = WebUtil.GetCookieValue("sitecore_starturl");
            if (user != null)
            {
                string[] startUrl = new string[] { user.Profile.StartUrl, cookieValue };
                cookieValue = StringUtil.GetString(startUrl);
            }
            return StringUtil.GetString(new string[] { cookieValue, "/sitecore/shell/applications/clientusesoswindows.aspx" });
        }

        private string GetValidUsername(string domainPrefix, string username)
        {
            if (!this.DomainExists(domainPrefix))
            {
                bool flag = false;
                string[] domainNames = Factory.GetDomainNames();
                for (int i = 0; i < (int)domainNames.Length; i++)
                {
                    string str = string.Format("{0}\\{1}", domainNames[i], username);
                    if (Membership.GetUser(str, false) != null)
                    {
                        if (this.IsAllowedToLogin(str))
                        {
                            return str;
                        }
                        flag = true;
                    }
                }
                if (!flag)
                {
                    this.loginError = string.Format("Cannot log in: The system failed to find a user named '{0}' in any domain", username);
                    Log.Warn(this.loginError, this);
                }
            }
            else
            {
                string str1 = string.Format("{0}\\{1}", domainPrefix, username);
                if (Membership.GetUser(str1, false) == null)
                {
                    this.loginError = string.Format("Cannot log in: The system failed to find a user named '{0}' in the '{1}' domain", username, domainPrefix);
                    Log.Warn(this.loginError, this);
                }
                else if (this.IsAllowedToLogin(str1))
                {
                    return str1;
                }
            }
            return null;
        }

        private bool IsAllowedToLogin(string fullName)
        {
            return true;
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            this.DoLogin(this.userToLogin);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            bool flag;
            this.loginError = "";
            if (LightLDAP.Configurations.Settings.Debug)
            {
                flag = true;
            }
            else
            {
                flag = (string.IsNullOrEmpty(base.Request.QueryString["debug"]) ? false : base.Request.QueryString["debug"] == "true");
            }
            this.isDebug = flag;
            string item = base.Request.ServerVariables["LOGON_USER"];
            if (string.IsNullOrEmpty(item))
            {
                this.loginError = "Error logging in using Single Sign-on: User information is not available <br><br>This error can happen either if you are not logged on to the Active Directory domain, or if anonymous access to this page has not been disabled in the Internet Information Server. Make sure you are logged in to the domain, and contact your system administrator if this problem persists.";
            }
            else
            {
                string str = item.Substring(0, item.IndexOf("\\"));
                string str1 = item.Substring(item.IndexOf("\\") + 1);
                this.userToLogin = this.GetValidUsername(str, str1);
                if (!string.IsNullOrEmpty(this.userToLogin))
                {
                    if (this.isDebug)
                    {
                        //this.RenderLoginInfo(this.GetFullMembership(this.userToLogin));
                        Log.Debug(string.Format("The user {0} has been logged in!", item), this);
                    }
                    this.DoLogin(this.userToLogin);
                }
            }
            if (!string.IsNullOrEmpty(this.loginError))
            {
                Label label = new Label()
                {
                    Text = this.loginError,
                    ForeColor = Color.Red
                };
                label.Font.Bold = true;
                base.Form.Controls.Add(label);
            }
        }

        private void RenderLoginInfo(string[] rolesForUser)
        {
            Button button = new Button()
            {
                Text = "Log me in"
            };
            button.Click += new EventHandler(this.LoginButton_Click);
            base.Form.Controls.Add(button);
            BulletedList bulletedList = new BulletedList();
            string[] strArrays = rolesForUser;
            for (int i = 0; i < (int)strArrays.Length; i++)
            {
                ListItem listItem = new ListItem(strArrays[i]);
                bulletedList.Items.Add(listItem);
            }
            base.Form.Controls.Add(bulletedList);
        }
    }
}