﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Data.Templates;
using Sitecore.Security;

namespace Profile.Index
{
    public class IndexableFacetableProfileProperty : IndexableProfileProperty
    {
        public IndexableFacetableProfileProperty(UserProfile owner, TemplateFieldItem f, Database d)
            : base(owner, f,d)
        {  }
        public override string TypeKey
        {
            get { return base.TypeKey + " facetable"; }
        }        

        public override string Name
        {
            get { return base.Name + " facetable"; }
        }
        //public override object Value
        //{
        //    get
        //    {
        //        if (Owner != null)
        //        {
        //            if (Owner.GetCustomPropertyNames().Contains(Field.Name))
        //                return Owner[Field.Name];
        //        }
        //        return (object)string.Empty;
        //    }
        //}
    }
}