﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Data.Managers;
using Sitecore.Data.Templates;
using Sitecore.Security;

namespace Profile.Index
{
    public class IndexableProfileProperty : IIndexableDataField
    {
      
        //private string _value;
        //private string _name;
        public UserProfile Owner;        
        public TemplateField Field;

        //public IndexableProfileProperty(string name,string value)
        //{            
        //    _value = value;
        //    _name = name;
        //}
        public IndexableProfileProperty(UserProfile owner, TemplateFieldItem f, Database d)
        {
            //_value = value;
            Field = TemplateManager.GetTemplateField(f.ID, f.Template.ID, d);
            Owner = owner;
            
        }
        public Type FieldType
        {
            get {

                FieldType fieldType = FieldTypeManager.GetFieldType(Field.Type);
                if (fieldType == null)
                {
                    return null;
                }
                return fieldType.Type;
            }
        }

        public virtual object Id
        {
            get { return Field.ID; }
        }

        public virtual string Name
        {
            get { return Field.Name; }
        }

        public virtual string TypeKey
        {
            get { return Field.TypeKey; }
        }

        public virtual object Value
        {
            get
            {
                if (Owner != null)
                {
                    if (Owner[Field.Name]!= null)
                        return Owner[Field.Name];
                }
                return (object)string.Empty; 
            }
        }
    }
}