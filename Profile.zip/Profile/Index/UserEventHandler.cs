﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using LightLDAP.Notification.Events;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Profile.Models.Index;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.LuceneProvider;
using Sitecore.Data.Events;
using Sitecore.Diagnostics;
using Sitecore.Events;


namespace Profile.Index
{
    public class UserEventHandler
    {
        private string ADDomain;
        public UserEventHandler(string addomain)
        {
            this.ADDomain = addomain;
        }
        public UserEventHandler()
        {
            
        }
        public void OnUserCreated(object o, EventArgs args)
        {
            var sArgs = (SitecoreEventArgs)args;
            var membershipUser = (MembershipUser)sArgs.Parameters[0];
            Log.Info("UserEventHandler:Event:OnUserCreated:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null && membershipUser.IsApproved)
                CreateUser(membershipUser);
        }

        public void OnUserCreatedRemote(object o, EventArgs args)
        {
            var cArgs = (UserCreatedRemoteEventArgs)args;
            var userName = cArgs.UserName;
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnUserCreatedRemote" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null && membershipUser.IsApproved)
                CreateUser(membershipUser);
        }

        public void OnADUserAdded(object sender, ADObjectEventArgs e)
        {
            string userName = string.Format("{0}\\{1}", this.ADDomain, e.UserName);
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnADUserAdded:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null && membershipUser.IsApproved) //It's normal, as we get notifications from all the AD forest, not only from the elements under the root of the connection string
                CreateUser(membershipUser);
        }

        public void OnUserUpdated(object o, EventArgs args)
        {
            var sArgs = (SitecoreEventArgs)args;
            var membershipUser = (MembershipUser)sArgs.Parameters[0];
            Log.Info("UserEventHandler:Event:OnUserUpdated:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            // Delete user from index if user is disbled
            if (membershipUser != null) //It's normal, as we get notifications from all the AD forest, not only from the elements under the root of the connection string
            {
                // Delete user from index if user is disbled
                if (!membershipUser.IsApproved)
                {
                    DeleteUser(membershipUser);
                }
                else
                {
                    UpdateUser(membershipUser);
                }
            }
        }
        public void OnUserUpdatedRemote(object o, EventArgs args)
        {
            var uArgs = (UserUpdatedRemoteEventArgs)args;
            var userName = uArgs.UserName;
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnUserUpdatedRemote:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null) //It's normal, as we get notifications from all the AD forest, not only from the elements under the root of the connection string
            {
                // Delete user from index if user is disbled
                if (!membershipUser.IsApproved)
                {
                    DeleteUser(membershipUser);
                }
                else
                {
                    UpdateUser(membershipUser);
                }
            }
        }
        public void OnADUserChanged(object sender, ADObjectEventArgs e)
        {
            string userName = string.Format("{0}\\{1}", this.ADDomain, e.UserName);

            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnADUserChanged:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null) //It's normal, as we get notifications from all the AD forest, not only from the elements under the root of the connection string
            {
                // Delete user from index if user is disbled
                if (!membershipUser.IsApproved)
                {
                    DeleteUser(membershipUser);
                }
                else
                {
                    UpdateUser(membershipUser);
                }
            }
        }                

        public void OnUserDeleted(object o, EventArgs args)
        {
            var sArgs = (SitecoreEventArgs)args;
            var userName = (string)sArgs.Parameters[0];
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnUserDeleted:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null)
                DeleteUser(membershipUser);
        }

        public void OnUserDeletedRemote(object o, EventArgs args)
        {
            var dArgs = (UserDeletedRemoteEventArgs)args;
            var userName = dArgs.UserName;
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnUserDeletedRemote:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null)
                DeleteUser(membershipUser);
        }
        public void OnADUserDeleted(object sender, ADObjectEventArgs e)
        {
            string userName = string.Format("{0}\\{1}", this.ADDomain, e.UserName);
            var membershipUser = Membership.GetUser(userName);
            Log.Info("UserEventHandler:Event:OnADUserDeleted:" + membershipUser != null ? membershipUser.UserName : "Membershipuser is null", this);
            if (membershipUser != null) //It's normal, as we get notifications from all the AD forest, not only from the elements under the root of the connection string
                DeleteUser(membershipUser);
        }

        #region Index interaction

        
        protected void CreateUser(MembershipUser membershipUser)
        {
            Log.Info("UserEventHandler:UserIndex:CreateUser:" + membershipUser.UserName, this);
            var index = ContentSearchManager.GetIndex("users");
            using (var context = index.CreateUpdateContext())
            {                                
                UsersCrawler craw = (UsersCrawler)index.Crawlers[0];
                craw.AddUser(new IndexableUser(membershipUser), context);
                context.Commit();
            }
        }

        protected void DeleteUser(MembershipUser membershipUser)
        {
            Log.Info("UserEventHandler:UserIndex:DeleteUser:" + membershipUser.UserName, this);
            var index = ContentSearchManager.GetIndex("users");

            using (var context = index.CreateUpdateContext())
            {
                UsersCrawler craw = (UsersCrawler)index.Crawlers[0];
                craw.DeleteUser(new IndexableUniqueId<string>(UsersCrawler.GetId(membershipUser.UserName)),context);
                context.Commit();
            }
        }

        protected void UpdateUser(MembershipUser membershipUser)
        {
            Assert.ArgumentNotNull(membershipUser, "membershipUser");
            Log.Info("UserEventHandler:UserIndex:UpdateUser:" + membershipUser.UserName, this);
            var index = ContentSearchManager.GetIndex("users");

            using (var context = index.CreateUpdateContext())
            {
                UsersCrawler craw = (UsersCrawler)index.Crawlers[0];
                craw.UpdateUser(new IndexableUser(membershipUser), context);
                context.Commit();
            }
        }

        #endregion
    }
}