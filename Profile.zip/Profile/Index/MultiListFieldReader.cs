﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.FieldReaders;
using Sitecore.Data;
using Sitecore.Text;

namespace Profile.Index
{
    public class MultiListFieldReader : FieldReader
    {
        public MultiListFieldReader()
        {
        }

        public override object GetFieldValue(IIndexableDataField indexableField)
        {
            IndexableProfileProperty field = indexableField as IndexableProfileProperty;
            List<string> strs = new List<string>();
            if (!string.IsNullOrWhiteSpace(field.Value.ToString()))
            {
                if (!IsBase64String(field.Value.ToString()))
                {
                    //List<string> strs = new List<string>();
                    var list = new ListString(field.Value.ToString(), '|');
                    if (list == null)
                    {
                        return strs;
                    }
                    foreach (string value in list)
                    {
                        string lowerInvariant = value;
                        if (!ID.IsID(lowerInvariant) && !ShortID.IsShortID(lowerInvariant))
                        {
                            continue;
                        }
                        lowerInvariant = ShortID.Encode(lowerInvariant).ToLowerInvariant();
                        strs.Add(lowerInvariant);
                    }
                }
                else
                {
                    List<ID> ids = DeserializeObject(field.Value.ToString());
                    foreach (var value in ids)
                    {
                        string lowerInvariant = value.ToShortID().ToString().ToLowerInvariant();
                        strs.Add(lowerInvariant);
                    }
                }
            }
            return strs;
        }

        public static List<ID> DeserializeObject(string str)
        {
            byte[] bytes = Convert.FromBase64String(str);

            using (MemoryStream stream = new MemoryStream(bytes))
            {
                return (List<ID>)new BinaryFormatter().Deserialize(stream);
            }
        }
        private bool IsBase64String(string s)
        {
            s = s.Trim();
            return (s.Length % 4 == 0) && Regex.IsMatch(s, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);

        }
    }
}