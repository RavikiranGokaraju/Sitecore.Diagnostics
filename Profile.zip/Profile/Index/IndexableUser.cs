﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Security;
using Profile.Index;
using Sitecore.ContentSearch;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Managers;
using Sitecore.Data.Templates;
using Sitecore.Security.Accounts;
using Sitecore.SecurityModel;

namespace Profile.Models.Index
{
    public class IndexableUser:IIndexable
    {
        private MembershipUser innerMembershipuser;
        private User innerUser;
        private Dictionary<object,IndexableProfileProperty> _fields;
        public IndexableUser(MembershipUser user)
        {
            innerMembershipuser = user;
            innerUser = User.FromName(user.UserName,false);
            _fields = new Dictionary<object,IndexableProfileProperty>();
        }
        public IndexableUser(User user)
        {
            innerMembershipuser = Membership.GetUser(user.Name); ;
            innerUser = user;
            _fields = new Dictionary<object, IndexableProfileProperty>();
        }
        public string AbsolutePath
        {
            get
            {
                if (innerMembershipuser != null)
                    return UsersCrawler.GetId(innerMembershipuser.UserName);
                else if (innerUser != null)
                    return UsersCrawler.GetId(innerUser.Name);
                else
                    return string.Empty;
            }
        }

        public System.Globalization.CultureInfo Culture
        {
            get { return CultureInfo.CurrentCulture; }
        }

        public string DataSource
        {
            get { return AbsolutePath; }
        }

        public IEnumerable<IIndexableDataField> Fields
        {
            get{return _fields.Values ;}
        }

        public IIndexableDataField GetFieldById(object fieldId)
        {
            return _fields[fieldId];
        }

        public IIndexableDataField GetFieldByName(string fieldname)
        {
            return _fields[fieldname];
        }

        public IIndexableId Id
        {
            get { return new IndexableId<string>(UsersCrawler.GetId(innerUser.Name)); }
        }

        public void LoadAllFields()
        {
            if (innerUser != null)
            {
                string templateid = innerUser.Profile.ProfileItemId;
                if (!String.IsNullOrWhiteSpace(templateid))
                {
                    using (new SecurityDisabler())
                    {
                        Database core = Database.GetDatabase("core");
                        var profileitem = core.GetItem(ID.Parse(templateid));
                        if (profileitem != null)
                        {
                            var templateitem = profileitem.Template;

                            //foreach (var item in innerUser.Profile.GetCustomPropertyNames())
                            //{
                            //    _fields.Add(item, new IndexableProfileProperty(item, innerUser.Profile.GetCustomProperty(item)));
                            //    _fields.Add(item + "facetable", new IndexableFacetableProfileProperty(item + "facetable", innerUser.Profile.GetCustomProperty(item)));
                            //}
                            if (templateitem != null)
                            {
                                foreach (var item in templateitem.Fields.Where(x => !x.Name.StartsWith("__") && !string.IsNullOrWhiteSpace(x.Type)))
                                {
                                    _fields.Add(item.Name, new IndexableProfileProperty(innerUser.Profile, item, core));
                                    _fields.Add(item.Name + "facetable", new IndexableFacetableProfileProperty(innerUser.Profile, item, core));
                                }
                                //_fields.Add("_description", new IndexableFacetableProfileProperty("_description", innerUser.Description));
                                //_fields.Add("_displayname", new IndexableFacetableProfileProperty("_DisplayName", innerUser.DisplayName));
                                //_fields.Add("_isadministrator", new IndexableFacetableProfileProperty("_IsAdministrator", innerUser.IsAdministrator.ToString()));
                                //_fields.Add("_clientlanguage", new IndexableFacetableProfileProperty("_ClientLanguage", innerUser.Profile.ClientLanguage));
                                //_fields.Add("_email", new IndexableFacetableProfileProperty("_Email", innerUser.Profile.Email));
                                //_fields.Add("_fullname", new IndexableFacetableProfileProperty("_FullName", innerUser.Profile.FullName));
                                //_fields.Add("_state", new IndexableFacetableProfileProperty("_State", innerUser.Profile.State));
                                //_fields.Add("_portrait", new IndexableFacetableProfileProperty("_Portrait", innerUser.Profile.Portrait));
                                //_fields.Add("_sitecoreid", new IndexableFacetableProfileProperty("_SitecoreId", innerUser.Name));         
                            }
                        }
                    }
                }
            }
        }

        public IIndexableUniqueId UniqueId
        {
            get { return new IndexableUniqueId<string>(UsersCrawler.GetId(innerUser.Name)); }
        }
    }
}