﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.FieldReaders;
using Sitecore.Data;
using Sitecore.Text;

namespace Profile.Index
{
    public class CheckBoxFieldReader : FieldReader
    {
        public CheckBoxFieldReader()
        {
        }

        public override object GetFieldValue(IIndexableDataField indexableField)
        {
            IndexableProfileProperty field = indexableField as IndexableProfileProperty;
            return field.Value;
        }
                
    }
}