﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using System.Xml;
using LightLDAP;
using LightLDAP.Configurations;
using LightLDAP.DataSource;
using LightLDAP.Notification;
using LightLDAP.Notification.Events;
using Lucene.Net.Documents;
using Profile.Models;
using Profile.Models.Index;
using Sitecore.Configuration;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Events;
using Sitecore.Eventing;
using Sitecore.Events;
using Sitecore.Search;
using Sitecore.Search.Crawlers;
using Sitecore.Security.Accounts;
using Sitecore.Xml;

namespace Profile.Index
{
    public class UsersCrawler : FlatDataCrawler<IndexableUser>
    {        
        private const string starttoken = "STARTTOKEN";
        private const string endtoken = "ENDTOKEN";
        private const string backslashtoken = "bsttoken";
        private const string spacetoken = "spacettoken";
        
        private UserEventHandler handler;
       
        public override void Initialize(Sitecore.ContentSearch.ISearchIndex index)
        {
            base.Initialize(index);
            InitializeListeners();
        }

        public UsersCrawler():base()
        {
            InitializeListeners();
        }

        private void InitializeListeners()
        {
            if (this.handler == null)
            {
                string section = "system.web/profile";                
                var profileconfiguration = System.Configuration.ConfigurationManager.GetSection(section) as System.Web.Configuration.ProfileSection;
                if (profileconfiguration != null)
                {
                    foreach (System.Configuration.ProviderSettings prov in profileconfiguration.Providers)
                    {
                        if (prov.Name == "ad")
                        {
                            string usenotification = prov.Parameters["useNotification"];
                            if (!string.IsNullOrEmpty(usenotification) && usenotification.ToLowerInvariant() == "true")
                            {
                                string addomain = prov.Parameters["sitecoreMapDomainName"];
                                this.handler = new UserEventHandler(addomain);
                                string connectionstringname = prov.Parameters["connectionStringName"];
                                string username = prov.Parameters["username"];
                                string password = prov.Parameters["password"];
                                string mapusername = prov.Parameters["attributeMapUsername"] ?? ObjectAttribute.SAMAccountName;

                                var connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings[connectionstringname].ConnectionString;

                                var notificationProvider = DirectoryNotificationManager.GetProvider(connectionstring, username, password, mapusername);
                                if (notificationProvider != null)
                                {
                                    notificationProvider.ObjectCategoryModified += new EventHandler<ObjectCategoryModifiedEventArgs>(this.handler.OnADUserChanged);
                                    notificationProvider.ObjectCategoryAdded += new EventHandler<ObjectCategoryAddedEventArgs>(this.handler.OnADUserAdded);
                                    notificationProvider.ObjectCategoryDeleted += new EventHandler<ObjectCategoryDeletedEventArgs>(this.handler.OnADUserDeleted);
                                }
                            }
                        }
                    }
                }
            }
        }
                
        public static string GetId(string userName)
        {
            // This is required to avoid problems with users with similar usernames. 
            // like kim and kimberly. When user kim is deleted both kim and kimberly will be kick of the index without these tokens.
            // It is not the best approach, but the most simple.
            return (userName).Replace(@"\", backslashtoken).Replace(" ", spacetoken);
            
        }
        public static string GetId(IIndexableUniqueId indexableUniqueId)
        {
            // This is required to avoid problems with users with similar usernames. 
            // like kim and kimberly. When user kim is deleted both kim and kimberly will be kick of the index without these tokens.
            // It is not the best approach, but the most simple.
            return indexableUniqueId.Value.ToString().Replace(backslashtoken,@"\").Replace(spacetoken," ");
        }

        protected override IEnumerable<IndexableUser> GetItemsToIndex()
        {
            return UserManager
                    .GetUsers()
                    .Where(x => x!= null && x.Domain!= null && x.Domain.Name != "sitecore")
                    .Select(x => Membership.GetUser(x.Name))
                    .Where(x => !x.IsLockedOut) // Check if user is disabled
                    .Select(x => new IndexableUser(x))
                    .Where(x=>x!=null);
        }

        protected override IndexableUser GetIndexable(IIndexableUniqueId indexableUniqueId)
        {
            return new IndexableUser(User.FromName(UsersCrawler.GetId(indexableUniqueId), false));
        }

        protected override IndexableUser GetIndexableAndCheckDeletes(IIndexableUniqueId indexableUniqueId)
        {
            return new IndexableUser(User.FromName(UsersCrawler.GetId(indexableUniqueId), false));
        }

        protected override IEnumerable<IIndexableUniqueId> GetIndexablesToUpdateOnDelete(IIndexableUniqueId indexableUniqueId)
        {
            IList<IIndexableUniqueId> result = new List<IIndexableUniqueId>(0);
            //result.Add(indexableUniqueId);
            return result;                        
        }

        protected override bool IndexUpdateNeedDelete(IndexableUser indexable)
        {
            return true;
        }
        public void AddUser(IndexableUser indexable,IProviderUpdateContext context)
        {
            base.DoAdd(context, indexable);
            NotifyIndexingEnd();
            
        }
        public void UpdateUser(IndexableUser indexable, IProviderUpdateContext context)
        {
            base.DoUpdate(context, indexable);
            NotifyIndexingEnd();
        }
        public void DeleteUser(IIndexableUniqueId indexableid, IProviderUpdateContext context)
        {
            base.Delete(context, indexableid);
            NotifyIndexingEnd();
        }
        private void NotifyIndexingEnd()
        {            
            object[] name = new object[] { this.Index.Name, false };
            object[] objArray = new object[] { this.Index.Name, false };
            Event.RaiseEvent("indexing:end", objArray);
            Event.RaiseEvent("indexing:end:remote", objArray);
            IndexingFinishedEvent indexingFinishedEvent = new IndexingFinishedEvent()
            {
                IndexName = this.Index.Name,
                FullRebuild = false
            };
            EventManager.QueueEvent<IndexingFinishedEvent>(indexingFinishedEvent);
        }
    }
}