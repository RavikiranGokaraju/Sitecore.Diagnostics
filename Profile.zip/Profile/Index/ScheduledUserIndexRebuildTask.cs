﻿//-----------------------------------------------------------------------
// <copyright file="ScheduledUserIndexRebuildTask.cs" company="ClearPeople Ltd">
//     Copyright (c) ClearPeople Ltd. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Globalization;
using Sitecore.Diagnostics;

namespace Profile.Index
{
    /// <summary>
    /// Summary description of ScheduledUserIndexRebuildTask
    /// </summary>
    public class ScheduledUserIndexRebuildTask
    {
        public string EmailAddress { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }

        private DateTime ParsedStartDate
        {
            get
            {
                DateTime time;
                if (!DateTime.TryParseExact(StartTime, "HH:mm:ss", new DateTimeFormatInfo(), DateTimeStyles.None, out time))
                {
                    time = DateTime.Parse("00:00:00");
                }
                return time;
            }
        }

        private DateTime ParsedEndDate
        {
            get
            {
                DateTime time;
                if (!DateTime.TryParseExact(EndTime, "HH:mm:ss", new DateTimeFormatInfo(), DateTimeStyles.None, out time))
                {
                    time = DateTime.Parse("00:59:00");
                }
                return time;
            }
        }

        public ScheduledUserIndexRebuildTask() { }

        public void Run()
        {
            if (!IsDue()) return;
            try
            {
                Log.Info("ScheduledUserIndexRebuildTask: Task Started.", this);
                var userIndex = Sitecore.ContentSearch.ContentSearchManager.GetIndex("users");
                if (userIndex != null)
                {
                    userIndex.Rebuild();
                    Log.Info("ScheduledUserIndexRebuildTask: Task Ended successfully.", this);
                }
                else
                {
                    Log.Error("ScheduledUserIndexRebuildTask: Could not re-index users. Users Index is Null.", this);
                }
            }
            catch (Exception ex)
            {
                Log.Error("ScheduledUserIndexRebuildTask: Could not re-index users. Exception occurred. Details: " + ex.Message, this);
            }
        }

        private bool IsDue()
        {
            var currentTime = DateTime.Now;
            return ((currentTime >= ParsedStartDate) && (currentTime <= ParsedEndDate));
        }
    }
}