﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using LightLDAP;

namespace Profile.ActiveDirectory
{

    public class ByteArraySettingsPropertyValue : StringSettingsPropertyValue
    {
        public override object PropertyValue
        {
            get
            {
                return base.PropertyValue;
            }

            set
            {
                var byteArray = value as byte[];
                base.PropertyValue = byteArray != null ? Convert.ToBase64String(value as byte[]) : String.Empty;
            }
        }

        public ByteArraySettingsPropertyValue(SettingsProperty property)
            : base(property)
        {

        }
    }
}
