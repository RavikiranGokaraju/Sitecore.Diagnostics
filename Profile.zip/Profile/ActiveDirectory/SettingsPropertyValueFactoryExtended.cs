﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LightLDAP;
using LightLDAP.Diagnostic;

namespace Profile.ActiveDirectory
{
    public class SettingsPropertyValueFactoryExtended : SettingsPropertyValueFactory
    {
        public override ADSettingsPropertyValue GetSettingsPropertyValue(ADSettingsProperty property)
        {
            switch (property.ADType)
            {
                case "byte array":
                    ConditionLog.Debug("SettingsPropertyValueFactory.GetSettingsPropertyValue - returning byte array value for a property {0} ({1})", new object[]
                  {
                    property.Name,
                    property.ADName
                  });
                    return new ByteArraySettingsPropertyValue(property);

                default:
                    return base.GetSettingsPropertyValue(property);
            }
        }
    }
}