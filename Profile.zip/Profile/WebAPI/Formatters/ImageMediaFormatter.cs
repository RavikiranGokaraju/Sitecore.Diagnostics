﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Net.Http.Headers;
using Business.Utils;

namespace Profile.WebAPI.Formatters
{
    public class ImageMediaFormatter : MediaTypeFormatter
    {
        public ImageMediaFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("image/jpeg"));
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("image/jpg"));
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("image/png"));
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("multipart/form-data"));
        }

        public override bool CanReadType(Type type)
        {
            return type == typeof(ImageMedia);
        }

        public override bool CanWriteType(Type type)
        {
            return false;
        }
        

        public async override Task<object> ReadFromStreamAsync(
         Type type, Stream stream, HttpContent content,
         IFormatterLogger formatterLogger)
        {
            if (!content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            var provider = await content.ReadAsMultipartAsync();

            var mediacontent = provider.Contents.First(x =>
                SupportedMediaTypes.Contains(x.Headers.ContentType));

            string fileName = mediacontent.Headers.ContentDisposition.FileName;
            string mediaType = mediacontent.Headers.ContentType.MediaType;

            using (var imgstream = await mediacontent.ReadAsStreamAsync())
            {
                byte[] imagebuffer = imgstream.ReadFully();
                return new ImageMedia(fileName, mediaType, imagebuffer);
            }
        }
    }
}