﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Business.Utils;
using Profile.Models;
using Profile.Services;

namespace Profile.WebAPI.Controllers
{
    public class ProfileController: ApiController
    {
        [HttpPost]
        public HttpResponseMessage SetProfileStatus(string status)
        {
            ProfileService service = new ProfileService();
            service.SetStatus(status);
            return new HttpResponseMessage(HttpStatusCode.NoContent);
        }
        [HttpPost]
        public HttpResponseMessage SetProfile(SearchProfileModel profile)
        {
            ProfileService service = new ProfileService();           
            service.SaveProfile(profile);
            return new HttpResponseMessage(HttpStatusCode.NoContent);
        }

        [HttpPost]
        public HttpResponseMessage SetProfileImage()
        {
            ProfileService service = new ProfileService();
            var r = Request;
            if (HttpContext.Current.Request.Files.AllKeys.Any())
            {
                var image = HttpContext.Current.Request.Files[0];
                if (image != null)
                {
                    if (image.IsImage())
                    {
                        if (service.SaveNewImage(HttpContext.Current.Request.Files[0]))
                            return new HttpResponseMessage(HttpStatusCode.OK);
                        else
                            return new HttpResponseMessage(HttpStatusCode.InternalServerError);
                    }

                    else
                    {
                        var results = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                        results.Content = new StringContent("The selected file is not a valid image");
                        return results;
                    }
                }
            }            
            return new HttpResponseMessage(HttpStatusCode.NoContent);
        }       

    }
}