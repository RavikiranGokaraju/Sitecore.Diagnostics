$USERS = Import-CSV F:\inetpub\uatADUSers.csv

$USERS|Foreach{
Set-ADUSer -Identity $_.SamAccountName -Title $_.title -Department $_.Department }