$pass = ConvertTo-SecureString -String "P@ssw0rd" -AsPlainText �Force
$pass = Read-Host "Enter an initial password" �AsSecureString
Import-CSV F:\inetpub\uatADUSers.csv | New-ADUser -Path "OU=VOA,DC=VOA,DC=QA" -AccountPassword $pass -Enabled $True -ChangePasswordAtLogon $False