$pass = ConvertTo-SecureString -String "P@ssw0rd" -AsPlainText �Force
$pass = Read-Host "Enter an initial password" �AsSecureString
Import-CSV c:\ADUSers.csv | New-ADUser -Path "OU=VOA,DC=QA,DC=Local" -AccountPassword $pass -Enabled $True -ChangePasswordAtLogon $False