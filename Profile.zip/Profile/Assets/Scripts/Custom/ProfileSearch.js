﻿
$(document).ready(function () {
    $('#profileSearchApply, #staff_directory_search_submit').on('click', function (e) {
        e.preventDefault();
        ProfilesearchRedirect();
    });
    $('#savestatus').on('click', function (e) {
        e.preventDefault();
        SaveStatus();
    });
    $('#update_profile').on('click', function (e) {
        e.preventDefault();
        SaveProfile();
    });
    $('#profileclear_filters').on('click', function (e) {
        e.preventDefault();
        window.location.href = "?" + BuildTextBoxSearchQuery();
    });
    //$('.searchPagination').not('.disabled').click(function (evt) {
    //    evt.preventDefault();
    //    var query = $('#searchTextbox').val();
    //    var pageNumber = $(this).attr('data-pageNumber');
    //    searchRedirect(query, pageNumber);
    //});
    //$('.searchSuggestion').click(function () {
    //    var query = $(this).html();
    //    searchRedirect(query, "", true);
    //});
});
function ProfilesearchRedirect() {

    var url = "?";
    var kk = $(".checkbox_group").each(function (index) {
        var fieldname = $(this).data("fieldname");
        var values = $(this).find(":input:checkbox:checked").map(function () {
            return encodeURIComponent(this.value);
        }).get().join("|");
        if (values)
            url = url + fieldname + "=" + values + "&";
    })
    url = url + BuildTextBoxSearchQuery();
    window.location.href = url;
}
function BuildTextBoxSearchQuery() {
    var url = "";
    var query = $('#peoplesearchtextbox');
    var fieldname = $(query).data("fieldname");
    var value = encodeURIComponent($(query).val());
    if (value && fieldname)
        url = url + fieldname + "=" + value + "&";
    return url;
}

function SaveProfile() {
    var profile = new Object();
    //profile.SpecialRole = $("#specialrole").val();
    profile.SpecialRoleFullList = BuildCheckboxList('specialroles');
    //profile.LicensePlate = $("#licenseplate").val();
    profile.Status = $("#status").val();
    //var newimage = $("#uploadimage").prop("files")[0];
    //if (newimage !== null) {
    //    profile.NewImage = newimage;
    //    profile.IsNewImage = true;    
    //}

    profile.ShowImage = $("#display_image").prop('checked');
    profile.SubscriptionsFullList = BuildCheckboxList('news_list_preferences');
    profile.SkillsFullList = BuildCheckboxList('profileSkills');
    profile.ExpertiseFullList = BuildCheckboxList('profileExpertise');
    profile.Telephone = $('#telephonenumber').val();
    profile.MobileNumber = $('#voamobilenumber').val();
    var url = '/api/Profile/SetProfile';
    $.ajax({
        url: url,
        type: 'Post',
        data: profile,       
        success: function (response) {
            var newimage = $("#uploadimage").prop("files")[0];
            if (newimage != null) {
                SaveProfileImage(); 
            } else { ShowUpdatedProperly(); }
            //location.reload();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Error: " + errorThrown);
        }
    });
}

function SaveProfileImage() {
    
    var newimage = $("#uploadimage").prop("files")[0];    
    if (newimage != null) {
        var ext = newimage.name.split('.').pop().toLowerCase();
        if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) != -1) {
            var fdata = new FormData();
            fdata.append("image", newimage);
            var url = '/api/Profile/SetProfileImage';
            $.ajax({
                url: url,
                type: 'Post',
                contentType: false,
                processData: false,
                data: fdata,
                success: function (response) {
                    ShowUpdatedProperly();
                    //location.reload();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert("Error: " + XMLHttpRequest.responseText);
                }
            });
        }
    }
}

function BuildCheckboxList(selector) {
    var subs = [];
    $("#" + selector).find(":input:checkbox:checked").each(function () {
        var option = new Object();
        option.Value = $(this).attr('id');
        option.Selected = true;
        subs.push(option);
    });
    return subs;
}

function SaveStatus() {
    var status = $("#status").val();
    var url = '/api/Profile/SetProfileStatus?status=' + status;
    $.ajax({
        url: url,
        type: 'Post',
        success: function (response) { ShowUpdatedProperly(); },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Error: " + errorThrown);
        }
    });
}
function ShowUpdatedProperly() {
    $.featherlight($("#update_lightbox"), {
        afterOpen: function (event) {
            setTimeout(function () {
                var current = $.featherlight.current()
                $('.cancel').on('click', function () {
                    current.close();
                });
                $('.qlform_buttons input[type="submit"], .qlform_delete_buttons input[type="submit"]').on('click', function () {
                    current.close();
                });
            }, 100);
        },
        afterClose: function (event) {
            location.reload();
        }
    });
}